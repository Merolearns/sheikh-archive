# WhatsApp Chat Export: Dr. Moustafa Kamel مسجد الانصار
Export date: November 20, 2026 at 4:14 PM

---

## March 30, 2026

[11:58 AM] __Messages and calls are end-to-end encrypted. No one outside of this chat, not even WhatsApp, can read or listen to them. Tap to learn more.__

---

## May 1, 2026

[12:10 PM] **You:** [Contact: BEGIN:VCARD
VERSION:3.0
N:Dad;US;;;
FN:US Dad
TEL;type=Mobile;waid=17149335771:+1 (714) 933-5771
EMAIL;TYPE=Home:afekry9801@gmail.com
EMAIL;TYPE=Home:afekry9810@gmail.com
EMAIL;TYPE=Home:afekry9801@gmail.com
EMAIL;TYPE=Home:afekry9810@gmail.com
PHOTO;BASE64:/9j/4AAQSkZJRgABAQAAAQABAAD/4gHYSUNDX1BST0ZJTEUAAQEAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADb/2wBDAAMCAgMCAgMDAwMEAwMEBQgFBQQEBQoHBwYIDAoMDAsKCwsNDhIQDQ4RDgsLEBYQERMUFRUVDA8XGBYUGBIUFRT/2wBDAQMEBAUEBQkFBQkUDQsNFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBT/wAARCABgAGADASIAAhEBAxEB/8QAHQAAAQQDAQEAAAAAAAAAAAAABgQFBwgAAQMCCf/EAEYQAAIBAgUCAwMHBgsJAAAAAAECAwQRAAUGEiEHMRNBUQgiYRQVMnGBkdEJFpOUofAjM0JSVFViZKOx4hc1REZ0grLB4//EABsBAAICAwEAAAAAAAAAAAAAAAUGAwQAAgcB/8QAMhEAAgECBAMGBQMFAAAAAAAAAQIDABEEEiExBVGRE0GBobHBFDJhcdEiJPBCcpLh8f/aAAwDAQACEQMRAD8Ad9T9Qda6d1/0kj6h6P8AB1dk2fLl8Wq6eQtlFdSVaS087+7ZYpioikCN738GzbY1OzD57QtT/sn9pnpf1HmcQ5FXhsjzORj8mp6cEsPGnqPokBZzIFYDilbm1yjNrXXGYan6J676P9Qp4sm6i5HlBrEqZHM0Ge01JapE8LsQWd0gO8Hn6T2FpEjkL2psrpOsfss12d5ZSSVYSlptR5eZWMTxIFDvIy7gCRTyTe61xc8AkDFwXZHKm5FmF97juPSgWiugYWBupttY9461DvVgN04/KA6OzuAfL5M/ahLwSttEInVsvO2w5IVDIB5k27YMPyj1BFL0l0vW+BCaqDUCRCoaJTKsT0tQXRXIuFZo4iQDzsW/bFd+t3VbMMx1r0b6hoj5rW0unMuqpJ6pRCtXXU1ZUCdTsACgyx3O0AAOLAdsWT/KKG/RPI7H/mGDt/01TiHODFiANt+tTZSJcOTvt0qvFRpb83/YfyvO5miqHzXU88sAQG8MbRPTsrH13Uu7jyt5jDp0zzih07ovqHqTKcokgymLQsGWTRALE3y6pjpYWYqT2aVZ5Ce9geLm2Hv2jMxy/JfZs6IaHoqJaU5lS0+cVCiTZLARAN5aIi4MklVK9zaxjbg87YzXWzZN0q1XpemAmzDUtdlsIhaFpN0ULTSswtwGEggABvcMQFPJAqW0UwQch1y/mp7GVbnvYnwv/wBqWOg2ro+i2kMrnnp2y+qrdJV2a0a1H06msqq+OGJljcrdPCpKeT3b3RXYA+dsdGaW/MLpDkeRSh0qIadBMjsHKzM3iSLccWDFgPgBye5hOk0FQap9p+DSsloMn0Rk1FHRQlTK00EKxMiSM5N/fn5J7qtrXJbE/wCqKpqnM4KaP3gh2AAd2Ivx+wffhg4ZCQ7Mdl0HueoHSlfjGItCbbt7/wCqW6To9qS1LD6XuIee3c/+vuOOsMa0ep5FIAWojJUDnnub/apw508ceWUMaMyqkYCluwJJt+0n7zhszeZYsxyupS6FzYlgQdvHcHkcMfqwczZmNCGiGHgj5qQT4nX1qh3thZbTUHWjIKnxVpWrsq8aokk+i8ymWJF+spDGg9T5jDZ7YmaU+fa86d5xSQNTJmeQ0taY5AA/vTybd1iedqgX/s4O/bg0/llPrfRefZk9WaWorZKSrWlALRwQzI7MgsSWInbjtdV+OI263arh1X0r6JsskclXl0uYZbUskTLtMb0pjFz9L+CeNri4ux7G4CXiwFknQ8wf5/lTdw8Fo8O/JWX+dKsX7fHT/KNTdO31FDCDqjIHVlkpoTJK9IzWkjfaRZF3CXcwbbsewAdzhb0V1xVa56BaYo6mKI5c2U/NEtI8QKzRxbqdt26/0ghv2FjhDpAJ1K6GZZTSZm1Q2a5EtHUV4PiOJWh8KUm/dlfeCD5gjAf7HuezZx0bip5EjWPLa+ekiZCSXU7Zrn43mYccWAwwKijEq42dfS3tQGfEyyYR1vYxv5G/uKptndZXUWW0+m8wp3p6nKKyq3pK12iZvDVordgFaJjwe7n7bO+2b1bzDXvTPpsHp46WizhWziSLb74cQxeGDybWFRLexINx6c1z6uRvF1V1isiNGxzirYBxY2MzEH6iCCPgRgg64Z/Hmr6GoIamaRcr0tl0MsDFhHHM8QkJUHgko8V2HoB/J4WVbs45kP0HQ06MDLLh5F21J8R+akD2lNXnqX7QGc1tBCGyTTcMeTw1FPSyRqNu/ckm7gN4r1AU2UFYxYGxJDenLPP1h07MyI9Ll1XBWP4ljGojkDsz3ttUKGYm44S/bkGGhtJ0+m/ZR1FqKSGIT11XHNG6SMLwxSrDGjL2Uh2m7Ds4NzYARrpcTZas9XFJJDU1BkV2V+drBlYcW4IZwR6GxxXxF0lWVu+x8/xUCPnSRU/p/SPvYXPW9XM9lfXTZ9rPqFqjNqOaH54qoWimZjMIAWlYwrIQCVRWiFgOAqcDjEymsVswoqmSRdpqlkZ78Wv7x/zxCfs55UuW9MaWYM5auqJal1fsp3eGLfC0YPPqfhiT195lUttW/c9h8cOnD0KYZb7nXrrXPeIzGTE6bIdPDT2qS8pZswLZrUgxxnmmjlFvCTtuIPG5vX0PfnCTVxDCjIa6neRb/t5xmnaOPNaeOuqI1kiU7KSJveEKKbWsfPjkm54GPWsBf5Gx/tj/AMcXk+apcST8Izc7eOoqB/bP0supeg2a5jGabdlGbJV+JKtyYmIiKqe4uZEby+h6gYojqPUdbmdPktRW1U9VGJ3q3jkY7TM/h+I4XsC2xbkDkKvcAY+s+baLodQ6MzPTmYbnpMzppKapaLbutIpUsu4EBgDwSDYgG2PkTrXTlXo7PcwyCuqop58tq5qU+DfYWRtjMpIBIOy4v8PMmyjxeK0wkGx9qceCk9iI3+YXPXfzq4fsjZ/JWdMpshq4lpMwyGumpZaRyVnRWYyBpIzyh3vKvYfxZ8wcN/TKRdCe0jr/AE1UuUiz8Lm1FNUt4fjPdpGjiU8P/HTC48qZvQ2a8h1BlfTb2o88pkzGkiyHVdN8rDR1atEtQSzbpHY8MXWoAUHvKoA7AeOveo6HR3VrQOvqKsSuhp91DXLTyJKI4bm+1QQd7JNPa5tdF7eZFZAsKMx1jax+23oaX2VZMVJGu063H339QRUK+1Cqr101MFUIL0xsPX5NFc/b3+3EdZznNRntZHU1IQSJTwUoEYsNkMSRJ9u1Fv8AG+JC9pqqgret+pJqeWOeJvk1pYnDK1qaIcEfEEfZgE0lVUNDqrJ6rNKcVeWU9ZDNV05CnxYVcNItmIDXUEbSeb288LmIsZ3AOlz6084Nv2cb7nKPQVYT2jdRLkGndJdLcvnjr5cspadswkhZY97IgSNWVWa1/elZWBteJgTiMoIRTwRxA3CKFB+oWwuySGr6gnWOtM7rBHWQuJYoPFIEks0sa7Yw9yUSNWG0N7o8LuMJCbC+IcZIZZc3cdvtsPShsKrDF2QNyvzf3HU+tXs0dl8+UaRyOgqgq1NLQwQShTcBljVSAfPkYd8NZ1XkhP8AvjL/ANaT8cZ+deSf1xl/60n446GjIqhQRpXLXlVmLE708QVM1K5eCaSFyLbo2Km31jHSXMaqo2+LUzS7e2+Qm37cMf515J/XGX/rSfjjPzryT+uMv/Wk/HG+dOYrztFtbNpT/XZtWZmV+VVDzBeymwA+wcX+OKR+1lo75P1EqK+LwzJVU8dUI40tZbbGDep3Rs3H871xZXWnU2myqH5NlMsNZVyJfx43Dxxc28u7cHjy4J9DXHqpX1GbZhR1tZM9RUyLIpkkNyFDBgo9FBZrAcC/GF/i8qNDlXUg3oxwbHBeIKgNywI8r+1JOrORSZjp9cxpWaOuytjUJIjlWVON9jcWIsGv393jvho1Lm0WvOlM9dHEXrKVo3kRFZRHKpXxCBfldjMeb8H1HBXqHUZppZKWlI8RWs0nfbY9h8cQtnNBLpisc05kGW1aNG69woIIKj4gcg/ZzzcTMMt27jvWcHX4rJC5s8bZkPMXuy+O48aH66tfMJklkCqyxRwgILDaiKi/bZRfHKKRYmDMpYDuo8x2P+eOY7YftIZc1bm0TiQoIbuxHoLcG48yR9l/TA0AsbV1WV48LAXOiqKlnLciOnumYhdXWolCSzCTdcMWWwIJNiFCggcXHbA5DEJ5kiPZ2Cn7cPmZZzX5hSSQyzeIjWuuxRfkH0w000UkNRFIUJCMG7jyOJMTGc6hRpakDhWIvh5nxDjMzMd+YFSw19psLm3a9sBdXn8q1K/JpnaKO+3xeSCRa17+8B3BPPOC2lq6fNKbfGRLEwKsrD7wRjXzXR/0SD9Ev4YM1zKJ1iJzi9Dmnc7jhmZKuSVpZCFWZ3LAD0Nz6+fx8sFmE3zXRj/hIP0S/hjdfM9PAXSNZABdt0vh2+234YytZGWVrqLUovzbzwM6/RDlUDke+Jgob0BVrj9gw2R6iqoZqmRGu01gGk95lAvYDsPP0w25nW1NdC3jTSS87gpNwD8B5YgnGaJh9KNcMgeHGRSE6Ajz0o4bTWXMzFoGZiSSzSuSfrJOGbUuTabNBU5fWVVNQTVER2ePUkEH+S+0uNwDAG3na2AbXnVSrq6ypy/J5jTUkUhQ1cD/AMJKQeSrDst/TvbvY2xG5PcnzOKc2MUEqovRDCcLxGYTPIVINxzrmVKmxBv2tg26V0BzXUM9KZfCApDJu+l2dQBa/wDaOAy4ODzo5W09FqmQSyCEyUsqhmPDWKNb0Fgrm/xOKkEgMgvTzxTiBl4fKtrNbTyqTPzK/vv+F/qxn5lf33/C/wBWBDUHWwRzeHktIsqK1mnrFIDDn6KAg8+6QSQe9xhNlPXCqWptmeXwyU5sL0l1ZeeTZiQ3HlcfXgkcVCDa9c3GC4iUz28NL1I+TZAconeQVRlV12lNlh379/r+/DvgVz3qTk2S0FFVJOK4Ve140pyCRHexc+luRY2JII4sSCrFpXViQDtQWZJQA8ote/lvWYGNTSVtXOaaKmlanSxLIhO82v39B+OCfDfnmf0OnKVKnMJjBA7iMPsZveIJAsAT5HHpIAua8gLBxlW5oL+bKz+iT/o2/DGfNlZ/RJ/0bfhjj1R1jPSZfks+S16iKokklFRTOGDbLDbxwRdjcHzGCrR2rE1NpxcymVKZ4yyVAvZEZRckE+ViD8L2ubXxAsyM5jG9GH7dIFxBXQm31FQFT5HUPIRKBA1z9Oxby+zz8zhSuno04lnZiLC6iwPw5v8AvfDoxXeSosL48k84VyTenos16aW02XJ8OpA81Ur6c84Q12XTUBO9Q0ZNllX6JI7/AFfbgkvc388buCCrAMpFiCL3HpjLmsDEUIq4bsR9+Ngg9ufqw7NkKNUyESGOn7oOXYfDy/cYx9N+GCY6gM9zY7doJv8AXja4rfOvOkFPSS1QYxJvC9+R+/riUD12ZTZsi2m9iDWf/PAbldJJl0LxzKje9cbT3Fh5/WDb6vjjVdQx1lRHMeJEYFife3gAcH7vuPnxiSOd4icpqjiMNBiyBMt7bb+1HlT1VrqujJhoYsvdlPvNJ4rAECxHAAIvfkHAzrzqMdV0Ay/5vFJ4NR4niePv3WDLa20fzr3+GExnO3aBZexHe/72H784RNlMNRVyTykyK9hsW428ck2Hme3p8cbHEytcMdDUEWBw0LB1SxG29DxkcoELEoCSFJ4BNgT+wfcMe46ueGnmgjmdIZtpkjViFe3a487XOONSDA0i33FWKj4nHhJC4WwNzfgj6sRXovYGv//Z
END:VCARD]

[12:11 PM] **You:** السلام عليكم ورحمة الله وبركاته 
هذا رقم الوالد يا شيخ

---

## May 8, 2026

[12:57 PM] **You:** السلام عليكم ورحمة الله وبركاته

[12:57 PM] **Dr. Moustafa Kamel مسجد الانصار:** Muslims around the world eagerly await the arrival of the best days of this worldly life: the first ten days of Dhul-Hijjah. These blessed days are considered a golden spiritual season, especially for Muslims living in the West, where materialism can often overshadow the soul. They are an opportunity to return to the light of faith and closeness to Allah. While the pilgrims prepare for the journey of a lifetime and a spiritual rebirth, those who are not performing Hajj should also prepare themselves to draw near to the rank of the pilgrims through worship and devotion. The true winner is the one whose heart is purified and elevated.

• A Moving Story About the Virtue of Sacred Times

It is narrated that one of the righteous predecessors would exert himself immensely during the first ten days of Dhul-Hijjah, to the point that few could match him. He used to say, “Do not extinguish your lamps during the nights of the ten days,” referring to spending the nights in prayer.

Another story is told of a man who had lived heedlessly throughout the year. When the ten days arrived and he saw the people turning to worship, he stood at the door of the mosque weeping and saying:
“O Allah, the pilgrims stand in Your sacred precincts, while I stand at Your door restrained by my sins. Do not deprive me of the blessings of these days.”
The sincerity of his broken heart on that first night became the cause of divine openings and guidance for him throughout the season.

⸻

First: Repentance Is the Condition for Turning to Allah and Having Deeds Accepted

The best preparation for these days is sincere repentance, for it is both the key to worship and the condition for its acceptance. As Imam Al-Ghazali explains, the darkness of sins leads to deprivation and prevents the limbs from being active in good deeds. Sin is a chain that restrains a person from walking toward obedience to Allah and a burden that weakens one from serving Him.

• A Moving Story About the Chains of Sin

A man once came to a scholar complaining:
“I prepare for night prayer with ablution and sincere intention, yet I never wake up for it.”
The scholar replied:
“My dear brother, do not disobey Allah during the day while expecting Him to stand you before Him at night. Your sins have chained you.”

Repentance is what breaks those chains and restores spiritual energy and eagerness for worship.

⸻

Second: Avoid the Two Most Dangerous Mistakes After Sinning

Many people fall into one of two traps:
either belittling sins until they become habitual and the heart dies spiritually, or falling into despair and losing hope in Allah’s mercy.

The Qur’an opens the doors of hope and washes despair from the hearts, affirming that Allah forgives all sins.

• A Moving Story About the Vastness of Allah’s Mercy

In a sacred hadith, Allah says:
“O son of Adam, if your sins were to reach the clouds of the sky and then you sought My forgiveness, I would forgive you without hesitation.”

It is also narrated that a man who had greatly wronged himself with sins came seeking repentance and asked:
“Can I really be forgiven?”
He was told:
“It is Allah, the One who stretches out His hand at night to accept the repentance of those who sinned by day.”

Despairing of acceptance is among Satan’s greatest wishes, so never allow him to plant that despair in your heart.

⸻

Third: Beware of the “Repentance of Liars”

The repentance of liars is seeking forgiveness with the tongue while the heart still insists on the sin.

True repentance means replacing blameworthy actions with praiseworthy ones. Whoever used to look at the unlawful should replace that with prolonged recitation and reflection upon the Qur’an. Whoever walked toward sin should replace those steps with frequent walks to the mosque.

• A Moving Story About Practical Repentance

Our master Ka‘b ibn Malik provided one of the greatest examples of sincere repentance after he stayed behind from the expedition of Tabuk. Allah saved him because of his truthfulness. His repentance was not mere regret; he even wished to give away his wealth in charity out of gratitude to Allah for accepting his repentance.

This is what practical repentance looks like: abandoning the sin and following it with righteous deeds from the same path through which one once disobeyed Allah.

⸻

Fourth: Means That Help One Attain Sincere Repentance

To purify the heart before these blessed ten days, one should:

1. Repeat repentance often: Whenever the sin is repeated, renew repentance. Allah does not tire until you tire.
2. Increase in supplication:
    “O Lord, accept my repentance and wash away my sins.”
3. Cut off the means to sin: By distancing oneself from harmful distractions, unhealthy phone usage, idleness, or anything that facilitates disobedience.
4. Keep righteous company: Companions who remind you of Allah and strengthen you upon goodness.

• A Moving Story About Changing One’s Environment

In the famous story of the man who killed one hundred people, the secret to the acceptance and firmness of his repentance was that he was instructed to leave the “land of evil” and travel to the “land of righteous people.”

Environment and companionship are fortresses that protect repentance from collapsing under the temptations of worldly materialism.

⸻

Conclusion

O Allah, allow us to reach the first ten days of Dhul-Hijjah, help us worship You during them, and grant us a sincere repentance that purifies our hearts before death.

[1:00 PM] **You:** جزاك الله خيرا

---

## May 22, 2026

[12:52 PM] **You:** السلام عليكم ورحمة الله وبركاته

[12:54 PM] **Dr. Moustafa Kamel مسجد الانصار:** Have I Conveyed the Message?”
Between the Prophet’s Farewell and the Bloodshed in San Diego
Friday Khutbah
Have I Conveyed the Message?”

Between the Prophet’s Farewell and the Bloodshed in San Diego

Friday Khutbah

⸻

First Khutbah

I seek refuge in Allah from Satan, the accursed.
In the Name of Allah, the Most Merciful, the Especially Merciful.

All praise is due to Allah, who perfected for us the religion, completed His favor upon us, and sent to us the Seal of the Prophets. I bear witness that there is no god but Allah alone without partner, and I bear witness that Muhammad is His servant and Messenger — who conveyed the message, fulfilled the trust, advised the nation, and through whom Allah removed darkness and hardship. May Allah’s peace and blessings be upon him, his family, his companions, and all who follow them with excellence until the Day of Judgment.

As to what follows: O Muslims, fear Allah as He should be feared, and do not die except in a state of Islam.

⸻

First: Stand in ‘Arafat

Believers, allow me today to take you to a place and time far away — yet closer to our hearts than our own veins.

We are in the tenth year after the Hijrah.
The sun pours its golden light over the desert of Arabia. One hundred and twenty-four thousand companions stand upon the plains of ‘Arafat, their hearts attached to the lips of one man standing upon his camel, al-Qaswa’, with emotions in his eyes beyond description.

That man is Muhammad ﷺ.
That day is the Day of the Farewell Pilgrimage.

The Prophet ﷺ opens his blessed mouth and says:

“O people, listen carefully to my words, for I do not know whether I shall ever meet you again after this year in this place.”

Pause for a moment, O Muslim.
Imagine the wind itself stopping. The mountains listening. The hearts of one hundred thousand companions freezing in their chests at those words.

The Prophet ﷺ knew he was bidding farewell.
He knew the curtain was about to fall.
He knew the message had reached its completion, and that the trust would now pass onto our shoulders — until the end of time.

⸻

Second: Words Carrying the Weight of Eternity

The Farewell Sermon was not ordinary speech.
It was the final testament of a departing Prophet, and the covenant of a nation being reborn.

The Prophet ﷺ said:

“Your blood, your wealth, and your honor are sacred to one another, just as this day, this month, and this city are sacred.”

The sanctity of human life.
The sanctity of dignity.
These are not values invented by the West in the eighteenth century. They were proclaimed by the Prophet ﷺ atop ‘Arafat fourteen centuries ago before one hundred thousand witnesses under an open sky.

Then he ﷺ said — and time itself seemed to stop:

“Let those who are present convey the message to those who are absent.”

Then he raised his hand to the sky three times and said:

“O Allah, have I conveyed the message?
O Allah, have I conveyed the message?
O Allah, have I conveyed the message?”

The companions replied:

“Yes!”

And he said:

“O Allah, bear witness.”

⸻

Third: San Diego — When They Try to Silence “I Have Conveyed”

Believers, now travel with me from ‘Arafat to San Diego, California.

A mosque where the remembrance of Allah is established. Worshippers arriving to fulfill the obligation of their Lord. Hearts at peace. Foreheads in prostration. Voices reciting the words of Allah.

Then comes one who hates hearing the remembrance of Allah. One who wants to erase the witness of those conveying the message. One who wishes to answer the Prophet’s ﷺ question with: “No, the message was not conveyed.”

The attack on the Islamic center in San Diego is not merely a criminal act. It is a message. A message that says:

“Stay in your homes. Be ashamed of your religion. Silence your adhan. Hide your Islam.”

So shall we answer this message with fear, retreat, and apology?

Or shall we answer as the companions of the Messenger of Allah ﷺ answered:

“Yes — you conveyed the message.”

⸻

Fourth: The Mission of Prophethood — What Does “Conveyed” Mean?

Muslims, the Prophet ﷺ was not sent to sit quietly in his home. He was not sent merely to worship privately. Allah says:

“O Messenger, convey what has been revealed to you from your Lord. And if you do not, then you have not conveyed His message.”
(Surah al-Ma’idah 5:67)

The prophetic mission has three dimensions:

* Conveying through wisdom and speech
* Bearing witness through character, presence, and conduct
* Bringing mercy to the worlds — not destruction

So when our mosques are attacked, it is not only Muslims who are attacked. The message of mercy itself is attacked.

And the correct response is not isolation — but greater conveyance, greater presence, and greater testimony that Islam is a religion of mercy, construction, and life.

I say these words of mine, and I seek forgiveness from Allah for myself and for you. Seek His forgiveness, for He is the Most Forgiving, the Most Merciful.

⸻

Second Khutbah

All praise is due to Allah, and peace and blessings be upon the Messenger of Allah.

⸻

Fifth: Lessons and Reflections

Lesson One: Life Is One Defining Stand

During the Farewell Sermon, the Prophet ﷺ realized that life is one great stand, and that he would be asked: Did you fulfill your mission?

And every one of us, O Muslim, will stand on our own Day and be asked:

What did you do with the trust entrusted to you?

That trust is:

* Your faith
* Your mind
* Your time
* Your family
* Your neighbors
* Your community

⸻

Lesson Two: Muslim Dignity Is Not Taken — It Is Surrendered

Islam did not collapse when Muslims were tortured in Makkah.
Nor did it weaken when the Prophet ﷺ was boycotted in the valley.

What weakens Islam is not the hatred of enemies — but the absence of Muslims from their mission.

When the houses of Allah are attacked, they should be filled — not abandoned.

⸻

Lesson Three: Constant Readiness for Departure

The Prophet ﷺ said:

“Be in this world as though you are a stranger or a traveler.”

The incident in San Diego reminds us that death may come while you are praying. It may come in the purest and most beloved places to your heart.

So are you ready?

Readiness for death does not mean fear of it. It means holding yourself accountable before you are held accountable:

* Have the obligations been fulfilled?
* Have rights been returned?
* Has the tongue spoken benefit?
* Have the hands built something lasting?

⸻

Sixth: Practical Duties for Every Muslim

Believers, let us leave this mosque today not merely with emotions — but with commitments.

1. On the Personal Level

Review your relationship with Allah before this day ends. Repent sincerely. Repair what has been broken. Know that death may be closer than you think.

2. On the Family Level

Teach your family that Islamic dignity is not a burden — it is a crown. Do not hide your Islam out of shame. Teach your children about this incident and tell them:

“We are Allah’s witnesses upon this earth.”

3. On the Community Level

Visit your local Islamic center. Get to know your non-Muslim neighbors. Build bridges through wisdom and good character. You are the living khutbah of Islam — not what others write about you.

4. On the Level of the Ummah

Do not stop at grieving over San Diego and other tragedies. Donate. Volunteer. Support organizations that defend justice through law, wisdom, and principled speech.

5. On Preparing for Departure

Write your will. Organize your affairs. Say farewell to your loved ones in the way farewells should be said. And above all:

End each day with an action you would be pleased to meet Allah with if it were your final deed in this world.

⸻

Conclusion: “O Allah, Have I Conveyed?”

Muslims, Allah will question His Prophet ﷺ on the Day of Judgment, and He will question every prophet — and every one of us.

“So We will surely question those to whom the message was sent, and We will surely question the messengers.”
(Surah al-A‘raf 7:6)

When Allah asks you:

“What did you do with the trust?”

Do not be among those who say:

“I was afraid. I was busy. I was waiting for the right time.”

Rather, be among those who say — relying upon Allah’s mercy, not their own strength:

“My Lord, I conveyed what I was able to convey, and You are the Most Generous of the generous.”

And finally remember:

Mosques were not built for us to visit death within them — but for life to emerge from them.

So be a living source of life, a breathing testimony, and a message that has not yet ended.

O Allah, honor Islam and the Muslims. Lift oppression and hardship from them. Grant victory to Your religion, Your Book, and the Sunnah of Your Prophet.

O Allah, protect the mosques and those who worship in them, and make Your houses flourish with Your remembrance until the Day of Judgment.

O Allah, comfort those who experienced fear within Your houses of worship, and replace their fear with security and peace.

O Allah, grant us a good ending and protect us from an evil ending.

“Our Lord, grant us good in this world and good in the Hereafter, and protect us from the punishment of the Fire.”

And establish the prayer.

“Indeed, Allah and His angels send blessings upon the Prophet. O you who believe, send blessings and peace upon him abundantly.”

[12:55 PM] **You:** جزاك الله خيرا

[12:57 PM] **Dr. Moustafa Kamel مسجد الانصار:** واياكم

---

## June 19, 2026

[12:28 PM] **Dr. Moustafa Kamel مسجد الانصار:** هجرة إلى الغرب أم هجرة منه؟


الحمد لله رب العالمين والصلاة والسلام على المبعوث رحمة للعالمين وبعد،

فهذه الجمعة هي الأولى في عام هجري جديد جعله الله عام الفتح والنصر والتأييد والفرج والفرح على أمة الإسلام وعلى الإنسانية جمعاء، وفي سياق الحديث عن الهجرة والتأمل في دروسها للمسلمين في الغرب، أوّد التوقف عند سؤال مركزي مهم في حياة المسلم الأوروبي ولا يكاد يتوقف أحد عن السؤال عنه، ولا ينفك المسلمون في الغرب عن التفكير فيه وهو: نهاجر إلى الغرب ونستوطنه أم نهاجر منه ونفارقه؟ حفاظاً على الدين والهوية بعد المتغيرات الكبرى على الساحة الغربية، وبعد تجدد صور الخطر على الدين والتدين بشكل عام، وفي الغرب بشكل خاص؟

وقد انتقل التهمم بالجواب على هذا السؤال من الجيل الأول والمهاجرين الجدد إلى الجيل الثاني وما بعده؛ رغم ظننا أن إشكالية التوطين وسؤال الهجرة هو في مجتمع الجيل الأول دون غيره! والواقع أن ظاهرة الهجرة العكسية آخذة في النمو والازدياد بحسب حجم الضغط على الدين والهوية في الأقطار الغربية المختلفة.

ولطالما أكدتُ كثيراً على ضرورة وأهمية التوطين للمسلمين في الغرب ونفي فكرة التأرجح أو التأقيت؛ لأنها تخالف منهج الأنبياء في توطين الدعوة في أوطان وبيئات بعثتهم، وتضر بالدين والتدين، وتجعل المسلم الأمريكي  متصفاً بالوصف المذموم الوارد في الحديث المروي بسند ضعيف مع صحة معناه وهو قوله ﷺ: “إن هذا الدينَ متينٌ، فأوغِلْ فيه برِفْقٍ، فإنَّ المُنبتَّ لا أرضًا قطعَ، ولَا ظهْرًا أبْقَى” البزار والبيهقي والحاكم بسند ضعيف عن جابر بن عبدالله رضي الله عنه، والمنبت هو المسافر الذي يُحمِّل دابته فوق طاقتها فلا هو حافظ عليها ولا هو بلغ وجهته وقصده الذي إليه؛ وكذلك المسلم الأمريكي المتأرجح بين موطن إقامته في أمريكا وبين بلده الأصلي لا هو أضاف وأفاد وطنه الأصلي ولا هو أفاد وأضاف مهاجره الأمريكي، فالتوطين يجعلك في مواجهة مباشرة مع التحديات والأخطار المحيطة بتدينك وتدين أولادك فتبحث لها عن حلول لتجاوزوها، والتأرجح أو التأقيت يجعلك مخدراً عن تلك التحديات مرحّلاً لها وهي تعمل عملها في نفسك ونفس أولادك حتى تصل بك إلى حالة الفصام النكد بينك وبين أولادك ومجتمعك فكراً وثقافة ولغة واهتماماً وعملاً.

وما نحتاج إليه هو الضبط الوسطي لمبدأ الهجرة أو التوطين؛ فهناك طرفان ووسط، طرف يحرّم الإقامة في الغرب ويراها شراً محضاً لا خير فيه ويوجب على المسلمين الهجرة منه، وطرف يوجب الإقامة في الغرب ويرفع شعار “إحراق السفن” بمعنى إلغاء فكرة الهجرة من الغرب بالكلية لأن سفن العودة أُحرقت فلا سبيل للرجوع للأوطان مجدداً، وفي تقديري أن الطرفين لا يمثلان الرؤية الوسطية المعتدلة التي تتمثل في عدم إلغاء مبدأ الهجرة متى تعينت سبيلاً للحفاظ على الدين، مع التأكيد على ضرورة وأولوية التوطين مع التدافع مع التحديات بقانونية وسلمية وحضارية وموازنة ومقاربة، ويمكننا إيجاز معالم الضبط الوسطي للتوطين والهجرة من الغرب وإليه فيما يلي:

1- مركزية الدين والتدين في قرار الهجرة: إن قرار الهجرة من الغرب أو من أي بلد في عصرنا يجب أن لا يُستبعد من قاموس المسلم المعاصر أبداً؛ لأن طبيعة المرحلة عدم الاستقرار، وتجدد المخاطر على الدين والتدين على نحو غير مسبوق، وتزيين الشبهات والشهوات في عقول وقلوب أولادنا بأوجه شديدة التعقيد مع ضعف طرق الحماية والتحصين المبكر لهم، والقرآن الكريم يوجب على المسلم الهجرة من وطنه الذي ولد فيه وأحبه وتعلق به إذا عجز عن إقامة الدين فيه، ويعتبر أنّ من ظلم الإنسان لنفسه أن يعيش في وطن لا يمكنه إقامة الفرائض والواجبات الدينية أو إظهار شعائر الإسلام فيه قال تعالى: ﴿إِنَّ الذِينَ تَوَفَّاهُمُ الْمَلَائِكَةُ ظَالِمِي أَنْفُسِهِمْ قَالُوا فِيمَ كُنتُمْ قَالُوا كُنَّا مُسْتَضْعَفِينَ فِي الْأَرْضِ قَالُوا أَلَمْ تَكُنْ أَرْضُ اللَّهِ وَاسِعَةً فَتُهَاجِرُوا فِيهَا فَأُوْلَئِك مَأْوَاهُمْ جَهنَّمُ وَسَاءَتْ مَصِيرًا﴾ [النساء: 97]، فمتى رأيت الخطر قريباً من أولادك محيطاً بهم ولا تملك له دفعاً أو منعاً وتعينت الهجرة سبيلاً واحداً لحفظ الدين عليهم وجبت الهجرة عليك.

2- معيار الخطر الموجب للهجرة وتغيير المكان: المعيار الذي يظهر به الخطر على الدين والهوية للمسلم الأمريكي  والذي يتوجب معه الهجرة من الغرب هو: إقامة الفرائض والواجبات الدينية خاصة الصلاة وبصورة أدق صلاة الجمعة، وتجنب الفواحش والكبائر؛ فعن عبدالله بن عمرو رضي الله عنهما أن أعرابياً جافاً جريئاً قدم على النبي ﷺ فقال: يا رسول الله، أين الهجرةُ إليك حيثما كنت، أم إلى أرضٍ معلومةٍ، أم لقومٍ خاصةً، أم إذا متَّ انقطعتْ؟ قال: فسكتَ رسولُ الله ﷺ ساعةً، ثم قال: أين السائلُ عن الهجرة؟ قال: ها أنا ذا يا رسول الله. قال: “إذا أقمتَ الصلاةَ، وآتيتَ الزكاةَ، فأنتَ مهاجرٌ وإن متَّ بالحَضْرَمَةِ”. قال: يعني أرضاً باليمامة.

وفي رواية: الهجرةُ: أنْ تهجرَ الفواحشَ، ما ظهَرَ منها، وما بطَنَ، وتقيمَ الصلاةَ، وتؤتيَ الزكاةَ، فأنتَ مهاجرٌ” أحمد وغيره بسند حسن. ويتأكد هذا المعيار بحديث فديك رضي الله عنه الذي كان قد أسلم، وأراد أن يهاجر فطلب منه قومه وهم كفار أن يبقى معهم، واشترطوا له أنهم لن يتعرضوا لدينه، ففر فديك بعد ذلك إلى النبي ﷺ فقال: يا رسول الله إنهم يزعمون أنه من لم يهاجر هلَك فقال النبي عليه الصلاة والسلام: “يا فديك أقم الصلاة، وآت الزكاة واهجر السوء، واسكن من أرض قومك حيث شئت” وظن الراوي أنه قال: “تكن مهاجراً” ابن حبان بسند صحيح. وأيضاً حديث: “البلاد بلاد الله، والعباد عباد الله، وحيثما أصبت خيراً فأقم” أحمد بسند صحيح عن الزبير بن العوام رضي الله عنه، فالأحاديث المذكورة تضع معياراً للبلد الذي يُشرع لك العيش فيه وهو إقامة الدين وإظهار شعائره واجتناب المعاصي والفواحش بحقك ومن تلي أمرهم من الأولاد والذرية، هذا هو المعيار وليس المعيار هو أن يكون وطن الإقامة ذا أكثرية مسلمة أو غير مسلمة، أو دار الكفر أو دار الإسلام، فقد ينضبط المعيار في بلد أكثريته غير مسلمة وقد يقع العكس خاصة في عصرنا الرقمي الشبكي الذي تراجع فيه دور وأثر المكان كثيراً في حفظ الدين والتدين.

3- البعد الرسالي للمسلم مهاجراً أو مستوطناً: في حوار لي مع بعض الشباب الذين ولدوا وازدادوا في الغرب، ولهم مساحة من المعرفة الشرعية والخوف على الدين قالوا: إن الحريات تراجعت كثيراً في أوروبا ولم تعد بيئة صالحة للدين والتدين وتفكيرنا أن نعيش في المدينة المنورة ونصلي في الحرم ونجدد إيماننا في جحر الإيمان ومئرزه ونجاور الحبيب المصطفى ﷺ!! قلت لهم: فأين الرسالة وأين الاقتداء بالأنبياء فيها، وأين دوركم في تثبيت الناس على الدين والبلاغ المبين العالمي للإسلام؟ لو كانت رسالة المسلم أن يعيش في مكة أو المدينة ويموت بها فلمَ هاجر الصحابة منها نشراً للدين وقياماً بالاستخلاف والشهود الحضاري على الناس؟ ولمَ وجد قبر أبي أيوب الأنصاري في إسطنبول؟ ولمَ وجدت قبور للصحابة في مصر وليبيا والشام وتونس وسائر البلدان ولم يؤثروا البقاء في مكة أو المدينة طلباً لفضلها وشفاعة النبي ﷺ لمن مات فيها وهي موطنهم أو مهاجرهم؟ لهذا فإن من المعايير المهمة للهجرة أو البقاء المعيار الرسالي؛ أي وطن تعظم رسالتك فيه أكثر؟ أي وطن ترضي ربك فيه أكثر؟ أي وطن يتعدى نفعك للناس فيه أكثر؟ ولهذا عظّم القرآن ثواب المهاجرين في سبيل الله؛ لأن الهجرة تعظّم أمر الدين والرسالة قال تعالى: ﴿وَالَّذِينَ هَاجَرُوا فِي اللَّهِ مِن بَعدِ مَا ظُلِمُوا لَنُبَوِّئَنَّهُمْ فِي الدُّنْيَا حَسَنةً وَلَأَجْرُ الْآخِرَةِ أكْبَرُ لَوْ كَانُوا يَعْلَمُونَ﴾ [النحل: 41].

4- قرار التوطين لابد أن يُتبع بعمل يحفظ الدين والهوية: إن قرار التوطين في الغرب لابد أن يتبعه عمل فردي وجماعي لحفظ الدين والهوية على الذرية والأجيال، فلابد من بناء المؤسسات الحافظة للدين والتدين، ولابد من بحث أسباب وسبل الغواية وتجددها وكيفية التعامل معها، ولابد من الواقعية في التعامل مع الفتن، ولابد كذلك من إيجاد البدائل الشرعية للمحرمات، لابد للأُسر والعائلات من الإفادة من تجارب الأسبقين الذين وُفّقوا مع أولادهم في الثبات على الدين والحفاظ على التدين، ولابد من إيجاد البيئة الحافظة للدين والتدين كما فعل النبي ﷺ عندما هاجر من مكة إلى المدينة فبنى المسجد، وآخى بين المهاجرين والأنصار، وأنشأ السوق، ووضع دستور المدينة، وكذلك فعل الصحابة في الحبشة فكان الخروج من الإسلام استثناءً لا أصلاً فلم يرتد عن الإسلام خلال ثلاثة عشر عاماً أو يزيد، وقد كانوا في بلد غير مسلم ونظام غير إسلامي سوى اثنين فقط، وواقع الحال في الغرب غير ذلك كما لا يخفى على كل راصد ومتابع لحركة التدين في أوروبا، وإيجاد كل ذلك يحتاج إلى خطط مدروسة، وتدبير محكم، وبذل للوقت والجهد والمال إن أراد المهاجرون أن يظفروا بالثواب الحصري المعد لهم والذي لم يرد في القرآن الكريم سوى مرة واحدة وهو النعيم المقيم قال تعالى: ﴿الَّذِينَ آمَنُوا وَهَاجَرُوا وَجَاهَدُوا فِي سَبِيلِ اللَّهِ بِأَمْوَالِهِمْ وَأَنْفُسِهِمْ أعْظَمُ دَرَجَةً عِنْدَ اللَّهِ وَأُوْلَئِكَ هُمُ الْفَائزُونَ﴾ [التوبة: 20]، ﴿يُبَشرُهُمْ رَبُّهم بِرَحْمَةٍ مِّنْهُ وَرِضْوَانٍ وَجَناتٍ لَّهُمْ فِيهَا نَعِيمٌ مُّقِيمٌ﴾ [التوبة: 21]، فقد تكرر العذاب المقيم في القرآن كثيراً أما النعيم المقيم فهو جزاء حصري للمهاجرين العاملين حيث لم يرد إلا في هذا الموضع.

اللهم صحح قصدنا واجعل هجرتنا في سبيل مرضاتك، ولا تقطع كلمة التوحيد من نسلنا، وحبب إلينا وإلى أولادنا الإيمان وزينه في قلوبنا وكره إلينا وإليهم الكفر والفسوق والعصيان واجعلنا وإياهم من الراشدين، وفرّج الكرب عن أهلنا وإخواننا في غزة وفلسطين واليمن والسودان وكل مكان، والحمد لله رب العالمين.

---

## July 3, 2026

[11:01 AM] **You:** السلام عليكم ورحمة الله وبركاته

[11:02 AM] **You:** شيخنا الحبيب ءأنت قادم اليوم؟

[11:11 AM] **Dr. Moustafa Kamel مسجد الانصار:** وعليكم السلام ورحمة الله وبركاته حبيبنا الغالي 
ان شاء الله

[11:16 AM] **You:** جزاك الله خيرا

[12:00 PM] **Dr. Moustafa Kamel مسجد الانصار:** واياكم

[12:55 PM] **Dr. Moustafa Kamel مسجد الانصار:** الرياضة بين متعة المشاهدة ووظيفة الممارسة


الحمد لله رب العالمين والصلاة والسلام على المبعوث رحمة للعالمين وبعد،
كتبت لي احدي الأخوات عن مراهنات بين مشجعي الفريقين المتضادين والشباب يراهن ثم أنهم عملو لهم آب اسمه كلشي


فإن العالم مشغول هذه الأسابيع بحدث رياضي عالمي كبير وهو مباريات كأس العالم؛ حيث يترقب الناس المباريات للمشاهدة والمتابعة والتحليل والتوقع ومنهم من يسافر للحضور المباشر وتشجيع الفرق التي يحب، وينفق في سبيل ذلك آلاف الدولارات في غفلة تامة عن الأضرار والمخاطر والسلبيات الناتجة عن هذه الحالة الشائعة والمتكررة خاصة مع مشاركة عدد كبير من الدول العربية في هذا الحدث الكبير، ومن أهم ما يجب التوقف معه في متابعة هذا الحدث هو الانشغال بمتعة المشاهدة والتشجيع وتضييع الممارسة للرياضة واستفادة البدن بها، فالرياضة التي يمارسها الإنسان تفيد بدنه وتقيه الكثير من الأمراض والمخاطر الصحية، وهي للشباب ضرورية حيث تبني أبدانهم وتصرفهم عن الشهوات والمحرمات، كما تقلل من ساعات استخدامهم للهواتف والشبكات، كما تقلل الرياضة التوتر وتحسن المزاج والصحة النفسية، وتحسن جودة النوم وتجعل صاحبها نشيطا قادرا على الإنجاز متجاوزا للكسل، أما المشاهدة فلا فائدة تعود منها على البدن أو العقل سوى المتعة الوقتية والفرح أو الحزن المؤقت لفوز أو هزيمة الفريق المفضل للمشاهد، والمستفيد الحقيقي من المشاهدة هم اللاعبون والساسة وأصحاب المصالح الذين يوظفون هذه الأحداث والانتصارات الكروية الوهمية في نسبتها لأنفسهم والتغطية بها على فشلهم وظلمهم ونهبهم لثروات شعوبهم، والمؤلم حقا هو الانشغال بهذا الحدث والاستمتاع به في ظل حصار أهلنا في غزة، وتعدد الآلام والجراح في واقع أمتنا المكلومة وكأن من يشاهد بحماس المباريات لا ينتسب للأمة الجريحة ولا يـتألم لألمها، وكأننا أمة هزل ليس فيها جد، لا أمة جد فيها ترويح مؤقت للنفس، وهذه معالم الرؤية الوسطية للتعامل مع هذا الحدث الرياضي ومثيلاته:

1- الترويح عن النفس مشروع بضوابطه

لا يمكننا تحريم المشاهدة والتشجيع لمباريات كأس العالم الجارية الآن فالأصل في الأشياء الإباحة قال تعالى:

﴿قُلْ مَنْ حَرَّمَ زينَةَ اللَّهِ الَّتِي أَخْرَجَ لِعِبَادِهِ وَالطَّيِّبَاتِ مِنَ الرِّزْقِ قُلْ هيَ لِلَّذِينَ آمَنُوا فِي الْحَيَاةِ الدنْيَا خَالِصَةً يَوْم الْقِيَامَةِ كَذَلِكَ نُفَصِّلُ الْآيَاتِ لِقَوْمٍ يَعْلَمُونَ﴾ [الأعراف: 32]

وقد أذن النبي ﷺ للسيدة عائشة رضي الله عنها بمشاهدة لعب الأحباش بالحراب في المسجد قائلا: تشتهين تنظرين؟ قالت: نعم، تقول السيدة عائشة رضي الله عنها: “فأقامني وراءه، خدّي على خدّه، وهو يقول: دونكم يا بني أرفدة! حتى إذا مَلِلتُ قال: حسبُكِ؟ قلتُ: نعم، قال: فاذهبي” متفق عليه.

فالنبي ﷺ هنا أذن لها بالمشاهدة وكان يشجعهم على فعلهم المباح، وقد أحسنت بعض المساجد في الغرب 
 إذ وضعت شاشات فيها لمشاهدة المباريات لتشجيع الشباب على البقاء في المسجد وأداء الفرائض وغض البصر، ولكن لابد من ضبط الترويح والمشاهدة بضوابطه الشرعية وأهمها:

	•	أن لا يشغل عن واجب أو يوصل إلى محرم؛ كتضييع الصلاة أو النظر إلى محرم
	•	عدم العصبية لفريق من الفرق
	•	عدم إضاعة الوقت والتوازن في اختيار فرق المتابعة والمشاهدة
	•	عدم الانشغال بها عن قضايا الأمة الكبرى
	•	تجنب الظلم غير المباشر بتشجيع فرق يترتب على فوزها المزيد من القهر والظلم للشعوب
	•	الاستفادة من إيجابيات المشاهدة كبث روح التعاون والجماعية، والتخلي عن القيم السلبية ونوازع الشر في النفس، وإظهار الأخلاق الحسنة عند الغضب

2- الحذر من الغرق في مخاطر المشاهدة والتشجيع

إن شعوبنا العربية المسلمة غرقت في التشجيع والفرح بالفرق الفائزة والحزن على الخاسرة إلى حد جعلها تذهل عن مخاطر وسلبيات هذه المباريات بل تغرق فيها وتصبح جزءا من منظومتها الفكرية والقيمية التي تتعارض مع منظومة وقيم الإسلام، ومن هذه المخاطر:

	•	العصبية المقيتة المذمومة في الإسلام؛ وقد رأينا كيف أدت العصبية للفرق إلى التقاتل والشجار بين المشجعين وإلى إثارة النعرات القومية والعصبية بين الدول والشعوب تلك التي هدمها الإسلام، والأصل أن تُظهر هذه الأحداث الرياضية تآخي المسلمين وتناصر الشعوب لا تعاركها وتدابرها، بل ربما وصلت الفُرقة والعداوة إلى البيت الواحد وإلى الأصدقاء
	•	تكريس الظلم والاستبداد؛ حيث يَنسِب المستبد انتصار فريق دولته لنفسه ويُشعر شعبه أنه قد حقق نصرا مبينا، بينما الواقع هزيمته الحضارية في شتى الميادين
	•	سفه الإنفاق على الكرة واللاعبين في ظل الشح بالميزانية والإنفاق على التعليم والصحة والأولويات الضرورية للشعوب
	•	اختلال منظومة القيم؛ فاللاعب يكسب ما لا يكسبه معظم العالم في أي تخصص ويصبح قدوة للشباب وحلما أن يصبحوا مثله، رغم أنه لا يضيف في الواقع شيئا لشعبه أو أمته سوى شهرته وثروته الخاصة
	•	صناعة البطولات الزائفة الوهمية للاعبين والدول وتخدير الشعوب وإلهائها بالكرة
	•	اختلال مفهوم الفوز والخسارة واعتبار المعيار الدنيوي هو معيار الفوز أو الخسارة رغم أن المعيار القرآني مختلف، قال تعالى:

﴿فَمَن زحْزِحَ عَنِ النَّارِ وَأُدْخِلَ الْجَنَّةَ فَقَدْ فَازَ وَمَا الْحَيَاةُ الدُّنْيَا إِلَّا مَتَاعُ الْغُرُورِ﴾ [آل عمران: 185]

	•	قلب الحقائق والمفاهيم؛ فيصبح الانتماء للوطن والأمة بقدر ما شجّعت وتدعم فريق بلدك لا بقدر ما تقدم له من علم وأثر حقيقي للنهوض وتجاوز الأزمة الحضارية التي تحياها الشعوب المسلمة

3- ضرورة الانتقال من المشاهدة إلى الممارسة

إن توظيف الحدث الرياضي الذي يتابعه العالم بأسره في الانتقال من مجرد المشاهدة إلى الممارسة هو واجب الوقت الحقيقي للرجال والنساء؛ فالرياضة تحفظ مقصدين من مقاصد الشريعة وهما: النفس والعقل، والنبي ﷺ قال مُصدِّقا قول سيدنا سلمان رضي الله عنه: “صدق سلمان” وذلك عندما قال لأبي الدرداء رضي الله عنه: “إنَّ لنَفْسِكَ عليكَ حقًّا، ولِرَبِّكَ عليكَ حقًّا، ولِضَيْفِكَ عليكَ حقًّا، وإنَّ لأهلِكَ عليكَ حقًّا؛ فأَعْطِ كلَّ ذي حقٍّ حقَّهُ” البخاري.

وممارسة الرياضة من حقوق البدن، وقد مارس النبي ﷺ العديد من أنواع الرياضة المتاحة والشائعة في زمنه؛ كالسباق والجري، وركوب الخيل والفروسية وقال: “ارموا واركبوا” البيهقي، وأبو داود، والترمذي بسند حسن.

ورياضة الرماية قال ﷺ: “مرَّ النَّبيُّ ﷺ على نَفَرٍ مِن أسلمَ يَنتَضِلونَ، فقال رسولُ اللهِ ﷺ: ارموا بني إسماعيلَ؛ فإنَّ أباكُم كان راميًا، ارموا وأنا مع بَني فُلانٍ، فأمسَكَ أحَدُ الفَريقَينِ بأيديهم، فقال رَسولُ اللهِ ﷺ: ما لَكُم لا تَرمونَ؟ فقالوا: يا رَسولَ اللهِ، نرمي وأنتَ معهُم! قال: ارموا وأنا معكُم كُلِّكُم” البخاري.

ومارس النبي ﷺ رياضة المصارعة، وكانت مشيته ﷺ مشية رياضية وصفها سيدنا علي بن أبي طالب رضي الله عنه بقوله: “إذا مشى تَكَفَّأَ تَكفُّؤًا كأنَّما ينحدِرُ من صَبَبٍ” أحمد والحاكم بسند حسن.

فالحاصل أن ممارسة الرياضة المتاحة والمباحة لكل مسلم في الغرب ضرورية لوقاية البدن وحمايته، والاقتداء بالنبي ﷺ في هذا الجانب المهم من جوانب الاقتداء به، والرياضة للمسلمة في الغرب آكد منها للمسلم بضوابطها الشرعية لمقاصد ووظائف لا تخفى.

4- بين الحماس لشهوة والفتور عن طاعة

تذاع مباريات كأس العالم لهذا العالم في أوقات متأخرة أو مبكرة جدا كالرابعة صباحا أو بعيد منتصف الليل؛ لفروق التوقيت في بلد اللعب، ورغم ذلك يستيقظ الناس ويتابعون بكل حماس ويقظة وبعد انتهاء المباراة ربما ينامون عن فريضة الفجر، وإذا رغّبناهم في قيام الليل وفضله حتى قبل النوم استثقلوه ولم ينشطوا له وتركهم له قبل الفجر آكد، فكيف يتحمس المسلم لشهوة آنية وقتية فارغة، ويترك النوم والراحة لأجلها ويشعر بمتعة فائقة وهو يتابعها ولا يحصُل له مثلها أو قريبا منها في العبادة فرضا أو نفلا، إنّ هذا التناقض المؤلم يشير إلى حقيقة موت القلب أو ضعف إيمان صاحبه فمتعة العبادة ولذتها لا تقارن أبدا بمتعة المشاهدة والتشجيع للكرة، فليراقب كل مستيقظ للمشاهدة فجرا قلبه وروحه ونشاطه لقيام الليل وحرصه عليه، واغتنام أصفى الأوقات وأغلاها للتوبة والاستغفار وإجابة الدعاء وكيف أضاعها في ترفيه يمكن استدراكه بالمشاهدة في وقت لاحق!!

اللهم أصلح فساد قلوبنا، وأصلح ذات بيننا، وأصلحنا وأصلح بنا، واجعل قلوبنا عامرة بذكرك وشكرك، وفرّج الكرب عن أهلنا في غزة وفلسطين وكل مكان، والحمد لله رب العالمين.

---

## July 10, 2026

[12:26 PM] **You:** السلام عليكم ورحمة الله وبركاته نعتذر من فضيلتكم عن عدم الحضور بسبب ظرف عائلي

[12:27 PM] **Dr. Moustafa Kamel مسجد الانصار:** وعليكم السلام ورحمة الله وبركاته 
الله يحفظكم ويرعاكم

[12:37 PM] **You:** جزاكم الله خيرا يا شيخنا

[5:29 PM] **Dr. Moustafa Kamel مسجد الانصار:** واياكم 
الله يبارك فيكم

---

## July 17, 2026

[12:26 PM] **You:** السلام عليكم ورحمة الله وبركاته 
نعتذر منكم يا شيخنا عن عدم حضورنا اليوم، وذلك لارتباطنا بخطبة. نسأل الله أن يبارك فيكم، ونلقاكم على خير بإذن الله.

[12:27 PM] **Dr. Moustafa Kamel مسجد الانصار:** وعليكم السلام ورحمة الله وبركاته حبيبنا 
وفقكم الله وفتح لكم ابواب الخير

---

## July 31, 2026

[11:40 AM] **You:** السلام عليكم ورحمة الله وبركاته 
نعتذر منكم يا شيخنا الحبيب عن عدم حضورنا اليوم، وذلك لارتباطنا بخطبة إن شاءالله. نسأل الله أن يبارك فيكم، و نراكم على خير بإذن الله.

[11:41 AM] **Dr. Moustafa Kamel مسجد الانصار:** وعليكم السلام ورحمة الله وبركاته حبيبنا 
ربنا يوفقك ويفتح عليك ولك ابواب الخير

[11:41 AM] **You:** جزاك الله خيرا يا شيخنا الغالي

[11:42 AM] **Dr. Moustafa Kamel مسجد الانصار:** واياكم حبيبي

---

## August 7, 2026

[12:57 PM] **Dr. Moustafa Kamel مسجد الانصار:** ١-الصحبة الصالحة سبيل لحفظ الدين في الغرب 
الحمد لله رب العالمين، والصلاة والسلام على المبعوث رحمة للعالمين، وبعد،
فقد تضاعف الخطر على الدين والتدين في عالم اليوم، خاصة في الغرب مع خصوصية البيئة، وتجدد وتضاعف تحدياتها المؤثرة والمهددة للدين حفظًا وبقاء، ويتجدد السؤال: كيف السبيل لحفظ الدين والتدين في الغرب؟ ومن أهم وسائل وعوامل حفظ الدين والتدين في الغرب: الصحبة الصالحة، فيصعب على المرء أن ينجو بأولاده في الغرب دون صحبة صالحة تعينهم على الاستمساك بالدين والاعتصام بحبل الله، وإني لأعلم من غيَّر مدينته التي يعيش فيها وتحمَّل في سبيل ذلك ما تحمل من تبعات مالية، وفقدان لكسب أفضل وعمل مستقر؛ لأن أولاده بلغوا مرحلة عمرية لا يجدون فيها صحبة تعينهم على الدين، فانتقل إلى مدينة بها مسجد وبيئة إسلامية يسعه أن يجد لأولاده فيها صحبة صالحة، وإني لأعلم أيضًا من كان انتقاله العكسي من أوروبا فرارًا بالدين إلى بلد ذي أكثرية مسلمة، وطلبًا للسلامة والنجاة بأولاده فلم يفلح في ذلك، رغم أن مؤسسات ووسائل حفظ الدين هناك كانت أفضل وأكمل، ولكنَّ أولاده فقدوا الصحبة الصالحة في أوروبا فتراجع التزامهم الديني، وتعرضوا لاضطرابات نفسية مع فقد الصحبة وتعذر تعويضها، وكان من حكمته أن عاد بأولاده إلى مستقره الأول؛ لأنه رأى الأثر الإيجابي للصحبة الصالحة على دين أولاده وسلامهم النفسي، وأن المحاضن التربوية في الخيار الآخر لم تعوضهم عن إيجابيات ومزايا الصحبة الصالحة، ولهذا فإن من أوجب الواجبات على المسلم الذي يعيش في الغرب أن يرقب وجود هذه الصحبة المناسبة لعمر أولاده قبل أن يتزوج وينجب ويستقر في أي مدينة أو بلد، وكم جاءني من شاب صالح متهمم بأمر صاحبه الذي انحرف بعد استقامة، أو ضلَّ بعد هداية: ماذا يفعل لاستنقاذه ورده إلى الطريق؟!. 
والشباب المسلم في الغرب حاجته إلى الصحبة الصالحة ليست كحاجة غيره؛ لأن طوفان التحديات والضغط على الدين فوق طاقته، ولأنه فاقد للمعينات الأخرى على الالتزام الديني لطبيعة منظومة الحياة في الغرب: تعليمًا ودراسة، وعملًا ووظيفة، واستقرارًا وأسرة، وعندما أُسأل عن سفر البنات للدراسة بعيدًا عن الأسرة أضع ضابطًا مهمًا للإباحة، وهو: وجود الصحبة الصالحة والبيئة المعينة على الالتزام الديني لهذه الفتاة، وأن لا تكون في مدينة أو جامعة لا مسجد فيها أو بنات مسلمات تستعين بعد الله بهن على مشاق الطريق.
فكل مسلم مسؤول عن استنقاذ أولاده من النار، قال تعالى: ﴿يَا أَيُّهَا الَّذِينَ آمَنُوا قُوا أَنفُسَكُمْ وَأَهْلِيكُمْ نَارًا وَقُودُهَا النَّاسُ وَالْحِجَارَةُ عَلَيْهَا مَلَائِكَةٌ غِلَاظٌ شِدَادٌ لَّا يَعْصُونَ اللَّهَ مَا أَمَرَهُمْ وَيَفْعَلُونَ مَا يُؤْمَرُونَ﴾ [التحريم: 6]، وقال صلى الله عليه وسلم: «كلكم راعٍ وكلكم مسؤول عن رعيته، فالأمير الذي على الناس راعٍ وهو مسؤول عنهم، والرجل راعٍ على أهل بيته وهو مسؤول عنهم، والمرأة راعية على بيت بعلها وولده وهي مسؤولة عنهم» متفق عليه من حديث عبد الله بن عمر، ويدل على أهمية البيئة التي يظن بها وجود الصحبة الصالحة حديث قاتل المئة نفس؛ فعن أبي سعيد الخدري رضي الله عنه أن النبي صلى الله عليه وسلم قال: «كان فيمن كان قبلكم رجل قَتَل تسعة وتسعين نفسًا، فسأل عن أعلم أهل الأرض، فدُلَّ على راهب فأتاه، فقال: إنه قتل تسعة وتسعين نفسًا فهل له من توبة؟ فقال: لا، فقتله فكمَّل به مئة، ثم سأل عن أعلم أهل الأرض، فدُلَّ على رجل عالم، فقال: إنه قتل مئة نفس، فهل له من توبة؟ فقال: نعم، ومن يحول بينه وبين التوبة؟ انطلِق إلى أرض كذا وكذا؛ فإن بها أناسًا يعبدون الله تعالى فاعبد الله معهم، ولا ترجع إلى أرضك؛ فإنها أرض سوء» متفق عليه. وهذه أضواء على الصحبة وأثرها على الدين في القرآن الكريم:
١ - الاقتداء بالأنبياء في طلب الصحبة
في سورة الكهف، وفي قصة من قصصها قصة موسى والخضر، فموسى عليه السلام نبي كريم من أولي العزم، ومع ذلك طلب الصحبة للتعلم، قال تعالى: ﴿قَالَ لَهُ مُوسَى هَلْ أَتَّبِعُكَ عَلَى أَن تُعَلِّمَنِ مِمَّا عُلِّمْتَ رُشْدًا﴾ [الكهف: 66]، كما طلب أبو بكر رضي الله عنه صحبة رسول الله صلى الله عليه وسلم في الهجرة، فعن عائشة رضي الله عنها قالت: قال صلى الله عليه وسلم: «إن الله أذن لي بالخروج والهجرة» فقال أبو بكر: الصحبة يا رسول الله؟ قال: «الصحبة» قالت عائشة: فوالله ما شعرتُ قبل ذلك اليوم أن أحدًا يبكي من الفرح حتى رأيتُ أبا بكر يومئذ يبكي رواه البخاري، وفيه ما يدل على أهمية وضرورة اتخاذ الصحبة الصالحة المعينة على الطريق، مهما بلغت درجة علمك واستقامتك، ومهما قلَّت التحديات والضغوط على التزامك الديني، وهل هناك من هو أحوج إلى الصحبة الصالحة من شبابنا وأولادنا في الغرب؟!
٢ - الصاحب الداعية المؤثر
يحدثنا القرآن الكريم عن صحبة سيدنا يوسف عليه السلام لاثنين ممن دخلوا معه السجن، فلم ينشغل بهمِّه وحبسه ظلمًا عن دعوتهما وإرشادهما إلى التوحيد، قال تعالى: ﴿يَا صَاحِبَيِ السِّجْنِ أَأَرْبَابٌ مُّتَفَرِّقُونَ خَيْرٌ أَمِ اللَّهُ الْوَاحِدُ الْقَهَّارُ * مَا تَعْبُدُونَ مِن دُونِهِ إِلَّا أَسْمَاءً سَمَّيْتُمُوهَا أَنتُمْ وَآبَاؤُكُم مَّا أَنزَلَ اللَّهُ بِهَا مِن سُلْطَانٍ إِنِ الْحُكْمُ إِلَّا لِلَّهِ أَمَرَ أَلَّا تَعْبُدُوا إِلَّا إِيَّاهُ ذَلِكَ الدِّينُ الْقَيِّمُ وَلَكِنَّ أَكْثَرَ النَّاسِ لَا يَعْلَمُونَ﴾ [يوسف: 39-40]، وقد أحسن التأتي لهما ودعوتهما بأبلغ وأفضل طرق الدعوة، فبرهن لهما على صدقه ونبوته قائلًا: ﴿قَالَ لَا يَأْتِيكُمَا طَعَامٌ تُرْزَقَانِهِ إِلَّا نَبَّأْتُكُمَا بِتَأْوِيلِهِ قَبْلَ أَن يَأْتِيَكُمَا ذَلِكُمَا مِمَّا عَلَّمَنِي رَبِّي إِنِّي تَرَكْتُ مِلَّةَ قَوْمٍ لَّا يُؤْمِنُونَ بِاللَّهِ وَهُم بِالْآخِرَةِ هُمْ كَافِرُونَ﴾ [يوسف: 37]، وهذه رسالة مهمة لشبابنا وبناتنا في الغرب أن يكونوا قدوة صالحة لزملائهم من غير المسلمين في الدراسة والعمل، وأن يبذلوا جهدهم لهدايتهم ودعوتهم إلى الإسلام بالحكمة وأبلغ السبل، وأن يكونوا مؤثرين لا متأثرين، قدوة لا فتنة، وهذا لا يكون إلا بالعلم والحكمة وطلب التوفيق من الله عز وجل.
٣ - حث القرآن الكريم على صحبة الأخيار الذاكرين والتحذير من صحبة الغافلين
قال تعالى: ﴿وَاصْبِرْ نَفْسَكَ مَعَ الَّذِينَ يَدْعُونَ رَبَّهُم بِالْغَدَاةِ وَالْعَشِيِّ يُرِيدُونَ وَجْهَهُ وَلَا تَعْدُ عَيْنَاكَ عَنْهُمْ تُرِيدُ زِينَةَ الْحَيَاةِ الدُّنْيَا وَلَا تُطِعْ مَنْ أَغْفَلْنَا قَلْبَهُ عَن ذِكْرِنَا وَاتَّبَعَ هَوَاهُ وَكَانَ أَمْرُهُ فُرُطًا﴾ [الكهف: 28] أمر الله تعالى رسوله الكريم بملازمة المؤمنين الصادقين، وحذر من الانصراف عنهم إلى صحبة أهل الدنيا المنشغلين بها الغافلين عن ذكره، ونهاه عن طاعتهم، ففي الآية تحذير من مخالطة الغافلين والصحبة لهم، فإن صحبتهم سم قاتل، والجلوس معهم تضييع وبطالة، فليرقب كل واحد منا صحبة أولاده، وهل لزم الذين يدعون ربهم بالغداة والعشي أم الذين اتبعوا هواهم وغفلت قلوبهم عن ذكره سبحانه وبحمده؟ وهل هو قدوة لأولاده فيمن يرون من أصحابه الذين يغشون مجلسه وبيته؟
٤ - استدامة الصحبة في الجنة
قال تعالى: ﴿الْأَخِلَّاءُ يَوْمَئِذٍ بَعْضُهُمْ لِبَعْضٍ عَدُوٌّ إِلَّا الْمُتَّقِينَ * يَا عِبَادِ لَا خَوْفٌ عَلَيْكُمُ الْيَوْمَ وَلَا أَنتُمْ تَحْزَنُونَ * الَّذِينَ آمَنُوا بِآيَاتِنَا وَكَانُوا مُسْلِمِينَ * ادْخُلُوا الْجَنَّةَ أَنتُمْ وَأَزْوَاجُكُمْ تُحْبَرُونَ﴾ [الزخرف: 67-70] وصف الله سبحانه وتعالى الأصدقاء بأنهم كلهم أعداء لبعضهم يوم القيامة، واستثنى الله المتقين، وذلك لأنه لم يجمعهم على الصحبة إلا حب الله عز وجل والصدق في طلب الله، ليست المصلحة أو المال أو المعصية التي جمعتهم كما جمعت غيرهم من الأصحاب، ولهذا كان الأصحاب الصالحون المتقون لله في الدنيا أصحابًا في الجنة، فكلما أحسست بمتعة في صحبة من لا يذكرك بالله ويلبي رغباتك وشهواتك أيها الشاب فتذكر أن تلك الصحبة ستحرمك من الجنة، وبما هوت بك مع صاحبك إلى النار، فكن على حذر ودبِّر لآخرتك.
٥ - شفاعة الصحبة
قال تعالى: ﴿فَمَا لَنَا مِن شَافِعِينَ * وَلَا صَدِيقٍ حَمِيمٍ﴾ [الشعراء: 100-101]، هذه الآية تدل على أن المؤمن يشفع لصاحبه يوم القيامة؛ قال قتادة: يعلمون والله أن الصديق إذا كان صالحًا نفع، وأن الحميم إذا كان صالحًا شفع، ويشرح هذا المعنى هذا الحديث العجيب عن أبي سعيد الخدري رضي الله عنه أن رسول الله صلى الله عليه وسلم قال: «إذا خلَص المؤمنون من النار فأمِنوا، فما لهم في الحق يكوُن أشدَّ مجادلةً لأحدكم لصاحبه في الدنيا من مجادلة المؤمنين لربهم في إخوانهم الذين أدخلوا النار، يقولون: ربنا كانوا إخواننا يصلون معنا ويصومون معنا ويحجُّون معنا، فأدخلتهم النار، فيقول: اذهبوا فأخرجوا من عرفتم منهم، فيأتونهم فيعرفونهم بصورتهم، لا تأكل النار صُوَرهم» النسائي وابن ماجة وابن خزيمة بسند صحيح. فابحث عن صديق يشفع لك ويكون صاحبك في الجنة، أو يسعى لاستنقاذك من النار.
أيها الأخوة.... تابعنا جميعًا فوز عبد الرحمن السيد في الانتخابات التمهيدية في ميتشجن ونحن نثمن هذا وندعوا له ولمجتمعنا ان يخرج امثاله ممن يعرفون الناس الدين الحق واسأل الله ان يحفظنا والمسلمين 
، وأن يجنبنا الفتن ما ظهر منها وما بطن، وأن يفرج الكرب عن أهلنا وإخواننا في غزة وفلسطين وكل مكان، والحمد لله رب العالمين.

---

## August 14, 2026

[3:03 PM] **You:** _You deleted this message_

[3:04 PM] **You:** PROJECT: Convert an Arabic WhatsApp Q&A Archive into a Book

I am going to upload a ZIP file containing an exported WhatsApp chat.

The chat is predominantly in Arabic and consists mainly of people asking questions to a Shaykh, followed by the Shaykh's responses. There may also be follow-up questions, follow-up answers, greetings, casual discussion, administrative messages, and other unrelated WhatsApp content.

The ultimate purpose of this project is to transform the relevant material from this WhatsApp archive into a professional, comprehensive Arabic Islamic Q&A book based on the Shaykh's actual responses.

This is not merely a summarization project.

The objective is to faithfully extract, organize, clean, and eventually publish the useful Q&A material while preserving the Shaykh's actual words, meaning, style, and scholarly content.

---

1. PRIMARY OBJECTIVE

Take the raw WhatsApp ZIP archive and transform it into a structured collection of:

السؤال → جواب الشيخ

or, when appropriate:

السؤال → جواب الشيخ → سؤال متابعة → جواب الشيخ

The final product should read like a properly organized Arabic question-and-answer book, rather than like a WhatsApp transcript.

The WhatsApp formatting, timestamps, irrelevant conversation, and technical clutter should be removed, while the substantive religious content should be preserved.

The final goal is eventually to create a polished DOCX and/or PDF Arabic book manuscript.

---

2. THE ARCHIVE IS MOSTLY IN ARABIC

This is extremely important.

The source material is predominantly Arabic, and Arabic is the primary language of the project.

Therefore:

- Process the material primarily as Arabic.
- Keep the final Q&A material in Arabic.
- Do NOT automatically translate the material into English.
- Do NOT turn the Shaykh's answers into English summaries.
- Do NOT transliterate Arabic unnecessarily.
- Preserve Arabic Islamic terminology.
- Preserve Qur'anic verses in Arabic.
- Preserve Arabic hadith quotations.
- Preserve Arabic quotations from scholars.
- Preserve Arabic duʿāʾ and religious expressions.
- Preserve the Shaykh's Arabic wording and style as much as reasonably possible.

If an English word or phrase appears naturally in the WhatsApp conversation, preserve it when relevant.

The initial manuscript should be Arabic, not English.

If I later want an English translation, that should be treated as a separate project.

---

3. THIS IS A SOURCE-PRESERVATION PROJECT

The most important principle is:

Do not change what the Shaykh said.

The Shaykh's responses are the core source material of the book.

You must NOT:

- Invent statements.
- Add religious rulings.
- Add your own opinions.
- Change the Shaykh's position.
- Strengthen or weaken his wording.
- Make the Shaykh sound more certain than he was.
- Make the Shaykh sound less certain than he was.
- Attribute something to the Shaykh that he did not say.
- Combine unrelated answers merely because they concern the same subject.
- Replace a lengthy answer with your own summary.
- "Correct" the Shaykh based on your own understanding.
- Rewrite his answer into something that merely sounds better but changes his wording or meaning.

The goal is to preserve the Shaykh's actual content and intended meaning.

---

4. WHAT EDITING IS ALLOWED?

Some editing is necessary because WhatsApp messages are fragmented.

For example, the Shaykh might send five consecutive messages:

«message 1
message 2
message 3
message 4
message 5»

If these five messages are clearly one continuous answer, combine them into a single answer.

Likewise, if someone sends three consecutive messages that together form one question, combine them into one question.

It is acceptable to:

- Remove WhatsApp timestamps.
- Remove the sender-name formatting from the final manuscript.
- Combine consecutive messages belonging to the same question.
- Combine consecutive messages belonging to the same answer.
- Remove obvious duplicated text.
- Correct obvious WhatsApp formatting artifacts.
- Fix minor punctuation or spacing problems where necessary for readability.
- Preserve the meaning while making fragmented messages readable.

However, do not substantially rewrite the Shaykh's answer.

There is a difference between:

cleaning WhatsApp formatting

and

rewriting the Shaykh's words.

Only the first should normally be done during the extraction stage.

---

5. IDENTIFY THE SHAYKH

The archive may contain many participants.

Before processing the entire archive, determine which participant is the Shaykh.

Look at the conversation context and identify the person who consistently provides the religious answers.

If the identity of the Shaykh is clear from the archive, use it consistently.

If there is genuine ambiguity, ask me to confirm the Shaykh's identity before making assumptions.

Do not assume that the person with the most messages is necessarily the Shaykh.

---

6. IDENTIFY QUESTIONS

The next task is to identify actual questions.

A question may consist of:

- One message.
- Several consecutive messages.
- A question followed by clarification.
- A question containing an image reference or contextual statement.
- A question that relies on the immediately preceding conversation.

For example:

«السلام عليكم يا شيخ عندي سؤال...»

followed by:

«هل يجوز...»

followed by:

«إذا كان الشخص...»

These may all constitute one question.

Combine them when the context clearly shows that they belong together.

---

7. IDENTIFY THE SHAYKH'S ANSWER

The Shaykh's answer may similarly consist of multiple consecutive WhatsApp messages.

For example:

«وعليكم السلام ورحمة الله وبركاته»

followed by several messages containing the explanation.

Treat them as one continuous answer when they clearly belong together.

Do not accidentally divide one answer into five separate answers merely because WhatsApp sent them as five messages.

---

8. FOLLOW-UP QUESTIONS

Some conversations will look like this:

Questioner:

Question.

Shaykh:

Answer.

Questioner:

But what about this situation?

Shaykh:

Further explanation.

If the second question clearly continues the original discussion, keep it together.

The final structure could be:

السؤال

[Original question + relevant follow-up]

الجواب

[Complete Shaykh response + clarification]

Do not artificially split one coherent scholarly discussion into many tiny entries.

---

9. MULTIPLE PEOPLE ASKING QUESTIONS

Sometimes several members may ask questions in the same discussion.

Do not automatically merge them.

If the Shaykh answers each person separately, keep the questions and answers separate.

If the Shaykh gives one response addressing several questions simultaneously, organize the material accordingly while preserving the original substance.

If it is unclear which answer belongs to which question, flag the ambiguity rather than guessing.

---

10. REMOVE IRRELEVANT WHATSAPP CONTENT

The archive will probably contain material that does not belong in the book.

Remove or exclude obvious non-substantive material such as:

- سلام عليكم by itself
- وعليكم السلام by itself
- جزاك الله خيرا
- بارك الله فيك
- آمين
- Thank-you messages
- Emoji-only messages
- "Thank you Shaykh"
- "May Allah reward you"
- "Please answer my question"
- Repeated requests for an answer
- Administrative announcements
- Group-management messages
- Messages about scheduling
- WhatsApp system messages
- People joining or leaving the group
- Deleted-message notifications
- Unrelated jokes
- Casual conversations
- Duplicate messages
- Messages that have no meaningful relevance to the Q&A

However, be careful.

Do NOT delete something simply because it is short.

If a short message provides essential context for understanding the question or answer, retain it.

---

11. PRESERVE CONTEXT

Suppose someone writes:

«يا شيخ، هل هذا يجوز؟»

By itself, this may be meaningless.

But the previous messages may explain exactly what "هذا" refers to.

In such cases, preserve enough context to make the final question understandable.

You may incorporate the necessary contextual information into the question if it is clearly established by the preceding conversation.

However, distinguish between:

what the questioner actually said

and

editorial clarification.

Do not make an editorial reconstruction appear to be an exact quotation from the questioner.

If necessary, mark something internally as:

[Editorial clarification]

or flag it for later review.

---

12. DO NOT SUMMARIZE THE SHAYKH'S ANSWERS

This is one of the most important requirements.

If the Shaykh writes a long answer, preserve the long answer.

Do not reduce it to:

«الشيخ يرى أن الأمر جائز.»

when the Shaykh actually provided several paragraphs of explanation.

The purpose of the book is to preserve the Shaykh's knowledge and explanations.

Therefore, the initial manuscript should contain the full relevant response.

Summaries can potentially be created later as:

- chapter introductions,
- indexes,
- abstracts,
- subject summaries,

but those should be separate from the Shaykh's actual answer.

---

13. ARABIC LANGUAGE QUALITY

Because this is an Arabic book, pay close attention to Arabic.

Preserve:

- Arabic spelling.
- Arabic punctuation.
- Arabic Islamic terminology.
- Proper names.
- Qur'anic quotations.
- Hadith quotations.
- Scholarly quotations.
- Duʿāʾ.
- رضي الله عنه
- رحمه الله
- حفظه الله
- صلى الله عليه وسلم
- and similar expressions when present.

Do not unnecessarily replace Arabic terms with English equivalents.

For example, retain terms such as:

- التوحيد
- العقيدة
- السنة
- البدعة
- الشرك
- الفقه
- أصول الفقه
- الحديث
- التفسير
- السلف
- الصحابة
- التابعون

where they occur naturally.

---

14. QUR'ANIC VERSES

If the Shaykh quotes Qur'an:

- Preserve the Arabic quotation.
- Preserve the surah reference if the Shaykh provided it.
- Do not invent a reference.
- Do not silently replace his wording with a different translation.
- Do not reconstruct missing Qur'anic text from memory and present it as if that was what the Shaykh wrote.

If a Qur'anic citation appears incomplete or questionable, flag it for later verification.

---

15. HADITH

If the Shaykh quotes a hadith:

- Preserve his wording as it appears in the archive.
- Preserve the source if he explicitly mentioned it.
- Do not invent a hadith reference.
- Do not silently replace the Shaykh's wording with a different narration.
- Do not attribute a hadith to a collection unless it can be established.

Later, if I ask for scholarly verification, we can separately verify:

- authenticity,
- wording,
- source,
- narrator,
- grading,
- and references.

But the initial task is faithful extraction.

---

16. QUOTATIONS FROM SCHOLARS

If the Shaykh quotes scholars such as:

- Ibn Taymiyyah
- Ibn al-Qayyim
- al-Nawawi
- Ibn Hajar
- al-Dhahabi
- al-Shafi'i
- Ahmad ibn Hanbal
- al-Bukhari
- Muslim
- or others,

preserve the quotation and attribution as it appears in the conversation.

Do not "correct" or expand the quotation without verification.

If the source appears uncertain, flag it for a later verification stage.

---

17. DO NOT FABRICATE MISSING TEXT

If the WhatsApp export contains something like:

«[This message was deleted]»

or an incomplete message, do not reconstruct what you think the person probably said.

If something is missing:

Mark it as missing or flag it for review.

Do not fill gaps with invented text.

---

18. KEEP THE ORIGINAL CHRONOLOGICAL ORDER INITIALLY

During the first extraction phase, preserve the chronological order.

This is important because context may depend on what happened immediately before or after a question.

Internally, keep track of:

- date,
- approximate time if useful,
- questioner,
- Shaykh,
- message sequence,
- topic,
- and any uncertainty.

These metadata do not necessarily need to appear in the final book.

They are primarily for verification.

---

19. ORGANIZE THE FINAL MATERIAL BY TOPIC

Once the complete Q&A material has been extracted and reviewed, organize it into logical chapters.

Possible subjects may include, only if the archive actually contains enough material:

1. العقيدة والتوحيد
2. الشرك والبدع
3. القرآن وعلومه
4. التفسير
5. الحديث وعلومه
6. الفقه
7. الصلاة
8. الصيام
9. الزكاة
10. الحج والعمرة
11. المعاملات المالية
12. الزواج والأسرة
13. تربية الأبناء
14. الأخلاق والآداب
15. طلب العلم
16. الدعوة
17. العلماء وطلبة العلم
18. الفتن والنوازل
19. المسائل المعاصرة
20. أسئلة متنوعة

These are merely examples.

Do not force the archive into this exact structure.

The actual chapter organization should be determined by the material found in the chat.

If the archive contains substantial material on a subject, give it a chapter.

If it contains only one or two unrelated questions, place them appropriately rather than creating unnecessary chapters.

---

20. DO NOT ORGANIZE TOO EARLY

First extract and understand the Q&A.

Then organize it.

Do not prematurely move messages around in a way that could cause questions and answers to become disconnected.

The recommended workflow is:

Extraction → verification → organization → editorial refinement

not:

Randomly reorganize while extracting.

---

21. DUPLICATES

WhatsApp exports may contain repeated material.

If the exact same message appears twice due to an export issue or obvious duplication, remove the duplicate from the final manuscript.

However, if two people independently ask essentially the same question, do not automatically delete one.

The fact that questions are similar may itself be meaningful.

Keep separate Q&A entries unless there is a clear reason to combine them.

---

22. PRESERVE DIFFERENT OPINIONS OR NUANCE

If the Shaykh says:

«هذه المسألة فيها خلاف...»

do not simplify it into:

«هذه المسألة حرام.»

If the Shaykh presents multiple opinions, preserve them.

If he says:

«الراجح...»

preserve that wording.

If he qualifies an answer with conditions, preserve the conditions.

If he says:

«في هذه الحالة...»

or:

«إذا كان كذا...»

retain the qualification.

The goal is to preserve the precision of the Shaykh's answer.

---

23. DO NOT ADD YOUR OWN RELIGIOUS ANALYSIS

You are organizing the source material.

You are NOT the author of the Shaykh's answers.

Therefore, do not insert statements such as:

«"This means that..."»

«"The correct Islamic position is..."»

«"According to Islam..."»

unless such wording comes from the Shaykh or I explicitly ask you to add an editorial section.

If you want to suggest something for editorial review, place it separately and clearly label it as an editorial note.

Never make it appear to be part of the Shaykh's answer.

---

24. EDITORIAL NOTES

If something genuinely needs attention, use a clear internal notation such as:

[للمراجعة]

or

[يحتاج إلى التحقق]

Examples:

- Unclear attribution.
- Incomplete quotation.
- Uncertain speaker.
- Missing message.
- Unclear connection between question and answer.
- Possible duplicate.
- Possible citation requiring verification.

Do not silently guess.

---

25. THE FINAL Q&A FORMAT

The basic final format should be:

السؤال الأول

السؤال:

[Question in Arabic]

الجواب:

[Complete Shaykh response in Arabic]

---

السؤال الثاني

السؤال:

[Question]

الجواب:

[Complete answer]

---

For a longer book, the preferred structure would eventually become:

الباب الأول: العقيدة والتوحيد

السؤال الأول

السؤال:

[Question]

الجواب:

[Shaykh's answer]

السؤال الثاني

السؤال:

[Question]

الجواب:

[Shaykh's answer]

---

الباب الثاني: ...

Continue in the same manner.

---

26. DO NOT OVER-EDIT THE QUESTIONS

Questions may be poorly written because they were typed quickly on WhatsApp.

You may clean obvious grammatical or formatting issues when necessary for readability, but preserve the questioner's actual meaning.

Do not transform a simple question into a sophisticated academic question that the person never asked.

For example, if someone asks:

«شيخ هل يجوز كذا؟»

don't turn it into a lengthy formal theological question.

Keep the original character of the question while making it readable.

---

27. THE SHAYKH'S VOICE MUST REMAIN HIS VOICE

This is particularly important.

If the Shaykh speaks conversationally, preserve that.

If he uses classical Arabic, preserve that.

If he quotes evidence extensively, preserve it.

If he gives a brief answer, don't artificially expand it.

If he gives a detailed answer, don't shorten it.

The book should feel like a collection of the Shaykh's actual answers, not like an AI-generated Islamic textbook.

---

28. SOURCE TRACEABILITY

Because this may eventually become a published book, it is desirable to maintain an internal connection between every final Q&A and the original WhatsApp messages.

Where technically possible, internally track:

- Original date.
- Original sender.
- Message order.
- Original message sequence.

For example:

Internal source reference:
2025-03-14 — Messages 1450–1467.

This does not necessarily need to appear in the published book.

It is for our editorial verification.

That way, if I later ask:

«"Where did this answer come from?"»

we can trace it back to the original conversation.

---

29. WORK IN STAGES

Because the ZIP archive may be extremely large, do not assume everything must be produced in one response.

Use a systematic workflow.

Stage 1 — Inspect the ZIP

Determine:

- What files are inside.
- Which file contains the WhatsApp text export.
- Approximate size.
- Number of messages if possible.
- Participants.
- Language.
- Identity of the Shaykh.

Do not alter the source file.

Stage 2 — Extract

Read the conversation and identify:

- Questions.
- Answers.
- Follow-ups.
- Relevant context.

Stage 3 — Clean

Remove:

- timestamps,
- WhatsApp formatting,
- system messages,
- irrelevant chatter,
- duplicates,
- non-substantive responses.

Stage 4 — Structure

Turn the conversation into:

Question → Answer

while maintaining the original content.

Stage 5 — Review

Check for:

- Missing Q&A.
- Incorrect speaker attribution.
- Incorrect question/answer pairing.
- Lost context.
- Duplicate material.
- Unclear passages.

Stage 6 — Categorize

Organize the extracted material into logical Arabic subject chapters.

Stage 7 — Manuscript

Create the polished Arabic Q&A manuscript.

Stage 8 — Publication preparation

Only after the content is stable should we consider:

- title,
- introduction,
- foreword,
- chapter introductions,
- footnotes,
- references,
- indexes,
- glossary,
- formatting,
- DOCX,
- PDF.

---

30. DO NOT CREATE A BOOK TITLE YET UNLESS ASKED

The first priority is the content.

Do not invent a final title simply because the project is intended to become a book.

We can decide the title after we understand the scope and subjects of the material.

---

31. DO NOT WRITE AN INTRODUCTION YET

Similarly, do not invent an introduction before the material has been extracted.

Once we know:

- what subjects the Shaykh discusses,
- the nature of the questions,
- the intended audience,
- and the overall character of the collection,

we can write a suitable introduction later.

---

32. POTENTIAL SECONDARY EDITORIAL STAGE

After the complete Q&A archive has been extracted, I may ask you to perform a second editorial pass.

That later stage may include:

A. Arabic proofreading

Correct:

- obvious spelling errors,
- punctuation,
- paragraph structure,
- spacing,
- formatting.

B. Citation verification

Verify:

- Qur'an references.
- Hadith sources.
- Scholarly quotations.
- Book titles.
- Names of scholars.

C. Topic organization

Move Q&A entries into the most appropriate chapters.

D. Cross-references

If the Shaykh answers related questions in different places, we may eventually add:

«انظر أيضًا: السؤال ...»

E. Indexing

Potentially create:

- Qur'an index.
- Hadith index.
- Scholar index.
- Subject index.
- Book/source index.

But none of this should alter the Shaykh's original answer.

---

33. IMPORTANT: DO NOT CONFUSE EDITORIAL VERIFICATION WITH THE SHAYKH'S WORDS

If you verify something independently and discover that a citation may be incorrect, do not silently change the Shaykh's answer.

Instead, preserve the source text and create a separate editorial note.

For example:

Original wording:
[Shaykh's original statement]

Editorial note:
[Reference requires verification.]

This protects the integrity of the source.

---

34. IF THE SHAYKH'S ANSWER IS INCOMPLETE

If the archive ends in the middle of a conversation, do not pretend the answer is complete.

Mark it as incomplete.

For example:

[انتهت المحادثة قبل اكتمال الجواب]

Similarly, if the question is present but the Shaykh's answer is not present, do not invent an answer.

---

35. IF A QUESTION HAS NO ANSWER

Do not automatically delete unanswered questions.

Initially, preserve them in a separate internal category:

Questions without an identifiable Shaykh response

This allows us to review them later.

They may eventually be removed from the published book unless we determine they are useful.

---

36. IF AN ANSWER HAS NO CLEAR QUESTION

Sometimes the Shaykh may spontaneously give advice or explanation without an obvious preceding question.

Do not force it into a fake question.

Place it into a separate internal category such as:

Unpaired Shaykh responses

Then we can decide later whether it belongs in:

- a chapter,
- a preface,
- a standalone section,
- or nowhere in the final book.

---

37. DO NOT THROW AWAY MATERIAL DURING THE FIRST PASS

The first pass should be comprehensive.

If you are unsure whether something belongs in the book:

keep it and flag it.

It is much easier to remove something later than to recover information that was discarded.

---

38. QUALITY STANDARD

The finished product should meet these standards:

Accuracy

The Shaykh's statements are faithfully represented.

Completeness

Relevant questions and answers are not accidentally omitted.

Attribution

Questions and answers are correctly attributed.

Arabic quality

The Arabic is readable and professionally formatted.

Organization

The material is logically categorized.

Traceability

Original messages can be located when necessary.

Scholarly integrity

No unsupported religious claims are introduced by the AI.

Editorial clarity

WhatsApp clutter is removed without destroying context.

---

39. WHAT NOT TO DO

Do NOT:

❌ Translate the entire archive into English.

❌ Summarize every answer.

❌ Rewrite the Shaykh into an AI-generated scholarly voice.

❌ Invent missing questions.

❌ Invent missing answers.

❌ Invent Qur'an or Hadith references.

❌ Attribute statements to the Shaykh without evidence.

❌ Delete difficult passages simply because they are difficult to organize.

❌ Combine unrelated questions.

❌ Remove important context.

❌ Change the Shaykh's religious position.

❌ Add your own fatwas.

❌ Present your editorial opinions as the Shaykh's words.

❌ Assume a missing message.

❌ Assume who said something when the archive is ambiguous.

---

40. WHAT TO DO

Do:

✅ Read the entire archive carefully.

✅ Identify the Shaykh.

✅ Identify each meaningful question.

✅ Identify the corresponding answer.

✅ Combine fragmented WhatsApp messages.

✅ Preserve the Arabic.

✅ Preserve the Shaykh's wording.

✅ Preserve important context.

✅ Remove irrelevant WhatsApp clutter.

✅ Keep track of source order.

✅ Flag uncertainty.

✅ Organize by subject after extraction.

✅ Review for omissions.

✅ Eventually create a professional Arabic manuscript.

---

41. FINAL BOOK VISION

The ultimate result should feel like a genuine Arabic collection of the Shaykh's scholarly Q&A sessions.

It should NOT feel like:

- a WhatsApp transcript,
- an AI summary,
- a collection of random screenshots,
- or an AI-written Islamic book.

It should feel like:

A carefully edited and organized collection of authentic questions and the Shaykh's actual answers.

The reader should be able to open the book and see:

---

السؤال

[Clear Arabic question]

الجواب

[Faithful, complete Arabic response from the Shaykh]

---

Then proceed naturally to the next question.

The WhatsApp origin should become essentially invisible in the final presentation, while the substance and voice of the Shaykh remain intact.

---

42. FIRST ACTION AFTER I UPLOAD THE ZIP

When I upload the ZIP file, do not immediately start rewriting everything into a book without first understanding the archive.

First:

1. Inspect the ZIP.
2. Locate the WhatsApp text export.
3. Determine the structure of the export.
4. Determine the participants.
5. Identify the Shaykh.
6. Determine the approximate size of the archive.
7. Determine how many messages/conversations need to be processed.
8. Tell me briefly what you found.
9. Then begin the systematic extraction.

If the file is too large to process all at once, process it in clearly defined sections while maintaining continuity and source references.

Do not make me manually separate the conversation unless absolutely necessary.

---

43. FINAL INSTRUCTION

Treat this as a serious long-term book project, not a casual WhatsApp-cleanup task.

The priorities are:

1. Faithfulness to the Shaykh.

2. Preservation of the Arabic source material.

3. Completeness.

4. Correct question-and-answer pairing.

5. Scholarly integrity.

6. Clear organization.

7. Professional book formatting.

The source archive is predominantly Arabic, so the primary final manuscript should also be Arabic.

The desired transformation is:

WhatsApp ZIP archive

→ Raw Arabic conversation

→ Relevant Q&A extraction

→ Clean Arabic Q&A

→ Verified and organized Q&A

→ Thematically arranged Arabic chapters

→ Professional Arabic book manuscript

→ Final DOCX/PDF

Do not rush.

Do not summarize away the Shaykh's knowledge.

Do not invent anything.

Do not translate unless explicitly asked.

Do not lose relevant material.

Preserve the Shaykh's actual answers, organize them intelligently, and help me turn the archive into the strongest, most faithful Arabic Q&A book possible.

[3:08 PM] **You:** Yes, proceed with the project according to the instructions I provided above.

Start with Phase 1: inspect and analyze the ZIP archive. Examine the files, identify the WhatsApp text export, determine the participants, identify the Shaykh, and assess the size and structure of the conversation.

Then proceed systematically with the extraction of the Arabic Q&A material.

Please do not wait for me to manually separate anything. Work through the archive yourself as far as the available tools allow.

Remember the core requirements:

1. The material is predominantly Arabic, so keep the source and manuscript in Arabic.
2. Identify the question → Shaykh's answer structure.
3. Combine fragmented consecutive messages when they clearly belong together.
4. Preserve the Shaykh's actual wording and meaning.
5. Do not summarize or rewrite his answers unnecessarily.
6. Remove irrelevant WhatsApp clutter.
7. Preserve important context.
8. Do not invent missing text, citations, questions, or answers.
9. Flag anything genuinely ambiguous rather than guessing.
10. Keep the material traceable to the original conversation where possible.
11. Do not translate the material into English unless I specifically ask you to.
12. Do not create the final book structure prematurely; first extract and understand the material, then organize it by subject.

Because the archive may be very large, work through it systematically in manageable sections if necessary, while maintaining continuity and keeping track of what has already been processed.

Begin now with the ZIP inspection and Phase 1. Once you have assessed the archive, continue directly into the extraction process rather than waiting for another confirmation from me, unless you encounter a genuine issue that requires my input.

[3:12 PM] **You:** Good. I see that you have produced the Markdown (.md) file containing the extracted Q&A material.

Now proceed to the next stage: quality control and verification.

Before we start designing the final book, I want you to carefully review the ".md" file you created and compare it against the original WhatsApp ZIP archive.

Please verify the following:

1. Make sure the questions have not been accidentally omitted.
2. Make sure the Shaykh's answers have not been shortened or summarized.
3. Make sure each question is correctly matched with the Shaykh's corresponding answer.
4. Make sure follow-up questions and follow-up answers have been kept together when they belong to the same discussion.
5. Make sure the Arabic wording has been preserved accurately.
6. Make sure no important context was removed.
7. Make sure irrelevant WhatsApp messages were appropriately excluded.
8. Check for duplicate questions or duplicate answers.
9. Check for messages that may have been incorrectly attributed to the Shaykh.
10. Identify any questions that have no identifiable answer.
11. Identify any Shaykh answers that have no identifiable question.
12. Identify any sections where the relationship between the question and answer is ambiguous.
13. Check that the dates and question numbering are internally consistent.
14. Check that the Markdown formatting is consistent throughout the file.

Do not rewrite the Shaykh's answers yet. This stage is about verification and completeness.

Create a separate Quality Control Report listing anything you find that needs attention.

For anything uncertain, give me the exact question number and explain the issue rather than guessing.

After completing the quality-control review, tell me:

- Total number of Q&A entries extracted.
- Number of entries that appear complete.
- Number of entries with missing/unclear answers.
- Number of entries requiring review.
- Any major issues you discovered.
- Whether you believe the ".md" file is ready for the next stage.

If everything looks good, the next stage will be to organize the Q&A into thematic Arabic chapters and prepare the actual book manuscript.

Do not create the final PDF/DOCX yet. We should verify the content first.

[3:16 PM] **Dr. Moustafa Kamel مسجد الانصار:** _This message was deleted_

[3:17 PM] **You:** I noticed a major issue with the extraction.

The ".md" file you produced contains only 13 questions, but the original WhatsApp archive should contain at least 1,000 questions, and potentially 2,000 or more.

Therefore, do not proceed to the book-writing or thematic organization stage yet. The 13 questions should NOT be treated as the complete dataset.

Please investigate why only 13 questions were extracted.

I want you to go back to the original ZIP file and determine:

1. The exact number of messages in the WhatsApp export, if possible.
2. The date range covered by the conversation.
3. The number of participants.
4. Which participant is the Shaykh.
5. Whether the ZIP contains the complete ".txt" WhatsApp export or whether there are multiple files/parts.
6. Whether your previous extraction process only processed a limited portion of the conversation.
7. Whether there is a file-size, token, context-window, parsing, or processing limitation that caused the extraction to stop early.
8. Where in the original conversation the 13 extracted questions came from.
9. Approximately how much of the original conversation those 13 questions represent.
10. Whether there are many more questions in the original archive that were simply not processed.

Most importantly:

I need you to perform a COMPLETE EXTRACTION, not a sample.

The goal is to identify all relevant Q&A exchanges throughout the entire WhatsApp archive, potentially numbering 1,000–2,000+ questions.

Do NOT simply increase the number of questions by guessing or automatically splitting messages. Each entry must represent a genuine question/discussion followed by the Shaykh's response.

If the archive is too large to process at once:

That is completely fine.

Process it in sequential batches/chunks.

For example:

- Batch 1: beginning of archive → first section
- Batch 2: next section
- Batch 3: next section
- Continue until the END of the archive.

Maintain a master numbering system so that the questions remain sequential:

Question 1
Question 2
Question 3
...
Question 100
...
Question 1000
...
Question 2000
etc.

Do NOT restart the numbering at 1 for every batch.

Also maintain enough internal source information to know which original messages each Q&A came from.

Very important:

Do not discard the previous 13 questions. Treat them as the beginning of the extraction only if they actually come from the beginning of the archive. Otherwise, determine exactly where they came from and place them correctly in chronological order.

The final extraction should cover the entire original WhatsApp archive from beginning to end.

Before continuing, first tell me:

A. How many total WhatsApp messages are in the original archive?

B. What date range does it cover?

C. How much of the archive did the previous extraction actually process?

D. Why did it stop at only 13 questions?

E. What is your proposed method for processing the entire archive without missing large portions of it?

Do not begin creating the final book yet.

The priority now is complete and accurate extraction of the entire archive.

[3:23 PM] **Dr. Moustafa Kamel مسجد الانصار:** نعم، ملاحظتك صحيحة تمامًا. الـ13 سؤالًا لم تكن استخراجًا كاملًا للأرشيف، وكان من الخطأ أن أتعامل معها سابقًا وكأنها بداية مشروع الاستخراج الشامل دون أن أوضح بجلاء أنها مجرد دفعة أولى.

عدت الآن إلى ملف ZIP الأصلي نفسه وفحصته مباشرة، بما في ذلك الملف النصي الكامل داخله.

A. كم عدد رسائل WhatsApp؟

الملف يحتوي على:

* ملف واحد فقط: _chat.txt
* حجم ملف النص الأصلي: 2,890,237 بايت ≈ 2.9 MB
* عدد رسائل WhatsApp الفعلية بعد تجميع الرسائل متعددة الأسطر: 8,014 رسالة
* عدد أسطر التصدير: 26,966 سطرًا
* عدد رسائل الشيخ: 2,415 رسالة
* عدد المشاركين/أسماء المرسلين الظاهرة في التصدير: 500 اسم/هوية مرسل، وتشمل أيضًا اسم المجموعة كمرسل لرسائل النظام.

وهذه الأرقام محسوبة مباشرة من الملف الأصلي، لا من ملف الاستخراج. WhatsApp Chat - أنت تسأل والشيخ يجيب.zip

⸻

B. ما الفترة الزمنية؟

الأرشيف كاملًا يمتد من:

28 أبريل 2020

إلى:

14 أغسطس 2026

أي أكثر من ست سنوات من المحادثات.

وأول رسالة في الملف هي رسالة إنشاء المجموعة، وآخر رسالة رسالة نظامية من WhatsApp في 14 أغسطس 2026.

⸻

C. ما مقدار الأرشيف الذي عالجه الاستخراج السابق؟

هنا ظهر سبب المشكلة بوضوح.

ملف:

qa_verified_batch_001.md

يحتوي فعلًا على 13 سؤالًا فقط، وليس 13 سؤالًا من الأرشيف كله. qa_verified_batch_001.md

والأهم: هذه الأسئلة الـ13 مأخوذة من الرسائل 19 إلى 147 فقط من أصل 8,014 رسالة.

أي أن الاستخراج السابق عالج تقريبًا:

147 ÷ 8,014 = 1.84% فقط من الرسائل.

وبالتالي فقد تم تجاهل أكثر من 98% من الأرشيف في تلك الدفعة.

وهذا يفسر تمامًا لماذا كان الناتج 13 سؤالًا فقط.

أين تنتهي الدفعة؟

آخر سؤال في الدفعة السابقة هو السؤال رقم 13، ومصدره:

الرسائل 144–147

أي أن الدفعة توقفت عمليًا في بداية الأرشيف جدًا. qa_verified_batch_001.md

⸻

D. لماذا توقف الاستخراج عند 13؟

بعد فحص الملفات وطريقة العمل السابقة، السبب واضح:

لم يكن هناك عجز في ملف ZIP، ولا مشكلة في حجم الملف، ولا أن الأرشيف يحتوي على 13 سؤالًا فقط.

بل الذي حدث هو أنني أنشأت دفعة استخراج أولية صغيرة من بداية المحادثة، ثم انتقلت مبكرًا إلى مرحلة ضبط الجودة لهذه الدفعة.

وهذا كان خطأً في منهج تنفيذ المشروع، وليس محدودية في الأرشيف.

والأهم:

الملف الأصلي ليس كبيرًا بصورة تمنع التعامل معه.

حجمه حوالي 2.9 MB فقط، وهو حجم يمكن تقسيمه إلى أجزاء متتابعة ومعالجته بصورة منهجية.

إذن:

لا توجد مشكلة file-size تمنع استخراج الأرشيف كاملًا.

⸻

E. هل يوجد بالفعل آلاف الأسئلة المحتملة؟

نعم، وبقوة.

التحليل الكامل للأرشيف أظهر:

* 8,014 رسالة
* 2,415 رسالة من الشيخ
* 1,908 مجموعات متتابعة من رسائل الشيخ، أي أن هناك 1,908 مواضع يبدأ فيها رد/مجموعة ردود للشيخ بعد رسائل من الآخرين.

وهذا لا يعني أن لدينا 1,908 سؤالًا مؤكدًا؛ لأن بعض مجموعات رسائل الشيخ قد تكون:

* إجابة على سؤال سابق.
* متابعة.
* رسالة إدارية.
* تصحيحًا.
* رابطًا.
* جوابًا قصيرًا.
* أو ردًا لا يمثل Q&A مستقلًا.

لكن الرقم يؤكد أن المادة أكبر بكثير جدًا من 13 سؤالًا.

كما أن البحث الأولي في الرسائل غير النظامية وجد مئات الرسائل التي تحتوي على علامات استفهام أو صيغ استفهام عربية. وهذا مجرد مؤشر أولي، وليس عدد الأسئلة النهائي.

⸻

هل ZIP كامل أم مقسّم؟

نعم، ZIP يحتوي على ملف نصي واحد كامل:

_chat.txt

ولا توجد أجزاء أخرى مخفية داخل ZIP.

أي لا يوجد:

* _chat (1).txt
* part 2
* part 3
* ملفات نصية أخرى

داخل الملف المضغوط.

إذن المصدر الأساسي الذي نحتاجه موجود كاملًا في هذا الملف الواحد.

⸻

ما الذي حدث للـ13 سؤالًا؟

وهذه نقطة مهمة جدًا.

الـ13 ليست عينة موزعة عشوائيًا من ست سنوات.

إنها دفعة من بداية الأرشيف، تقريبًا من:

9/26/2021 → 10/8/2021

وتبدأ من الرسائل 19–20 تقريبًا، وتنتهي عند 144–147.

مثلًا:

* السؤال الأول مصدره الرسائل 19–20. qa_verified_batch_001.md
* السؤال الثاني مصدره 25–26. qa_verified_batch_001.md
* السؤال الثالث مصدره 29–33. qa_verified_batch_001.md
* السؤال الرابع مصدره 38–40. qa_verified_batch_001.md
* السؤال العاشر مصدره 130–131. qa_verified_batch_001.md
* السؤال الثالث عشر ينتهي عند 144–147. qa_verified_batch_001.md

إذن نستطيع تحديد مكانها بدقة، ولن نضطر إلى إعادة اكتشافها.

⸻

النتيجة المهمة جدًا

لا نبدأ الكتاب.

لا نبدأ التصنيف الموضوعي.

لا نعتمد ملف الـ13 سؤالًا كقاعدة للكتاب.

سنعتبره فقط:

Batch 001 — أول دفعة استخراج، ويجب دمجها لاحقًا في قاعدة البيانات الرئيسية بعد التحقق منها.

⸻

المنهج الجديد الذي سأتبعه

سأغير طريقة العمل بحيث لا يتكرر هذا الخطأ.

المرحلة الجديدة

سأقسم الأرشيف كاملًا زمنيًا ومتسلسلًا إلى دفعات، وليس إلى عينات.

مثلًا:

Batch 001: بداية الأرشيف → نطاق محدد
Batch 002: النطاق التالي
Batch 003: النطاق التالي
…
حتى:

آخر رسالة في 14 أغسطس 2026

والترقيم سيكون متصلًا:

السؤال 1
السؤال 2
…
السؤال 100
…
السؤال 1000
…
السؤال 2000

ولن يعاد الترقيم في كل دفعة.

⸻

والأهم: لن أعتبر كل جواب للشيخ سؤالًا جديدًا

سأستخدم البنية التالية:

رسائل السائل

↓

سؤال حقيقي

↓

رسائل الشيخ المتتابعة

↓

جواب كامل

↓

متابعة إن وجدت

↓

جواب المتابعة

ثم أنتقل إلى الحوار التالي.

وهذا يمنع أن تتحول 5 رسائل متتابعة للشيخ إلى خمسة أسئلة وهمية.

⸻

سأحتفظ بثلاث فئات منفصلة

1. Q&A مؤكد

سؤال واضح + جواب الشيخ واضح.

2. Q&A يحتاج مراجعة

يوجد سؤال وجواب محتمل، لكن العلاقة بينهما غير مؤكدة.

3. غير مرتبط

مثل:

* رسائل الشكر.
* الإدارة.
* الروابط.
* الإعلانات.
* رسائل الشيخ التي لا يوجد سؤال واضح لها.
* أسئلة بلا جواب.

لن أحذف الفئة الثالثة من المصدر الداخلي؛ لأنك طلبت ألا نفقد المادة في المرحلة الأولى.

⸻

التتبع

كل سؤال في الاستخراج الكامل سيحمل داخليًا شيئًا مثل:

السؤال 0001

التاريخ: 26/09/2021
السائل: …
رسائل السؤال: 19–20
رسائل الجواب: 20
الحالة: مكتمل

وهكذا يمكننا فيما بعد الرجوع إلى المصدر الأصلي بدقة.

⸻

وأمر مهم جدًا بخصوص التقدير 1,000–2,000

لن أضع رقمًا مصطنعًا للوصول إلى 2,000.

إذا كان الأرشيف يحتوي فعليًا على:

1,147 Q&A → سيكون الناتج 1,147.

إذا كان:

1,836 → سيكون 1,836.

إذا كان:

2,241 → سيكون 2,241.

المعيار هو وجود سؤال حقيقي وجواب مرتبط به، وليس الوصول إلى رقم معين.

⸻

الخلاصة الحالية

[3:24 PM] **You:** ممتاز. هذا هو المنهج الذي أريده بالضبط.

الآن انتقل من مرحلة التحليل إلى التنفيذ الفعلي للاستخراج الشامل.

ابدأ باستخراج الأرشيف كاملًا من أول رسالة إلى آخر رسالة، على دفعات متسلسلة ومنظمة، مع الالتزام بكل ما ذكرتَه في رسالتك السابقة.

أريد منك تحديدًا:

1. ابدأ من أول الأرشيف واستمر حتى آخر رسالة بتاريخ 14 أغسطس 2026.
2. لا تتوقف عند دفعة واحدة أو عدد صغير من الأسئلة.
3. لا تنتظر مني تأكيدًا بعد كل دفعة؛ استمر تلقائيًا في الدفعات المتتابعة ما دامت الأدوات والملفات تسمح بذلك.
4. حافظ على ترقيم الأسئلة بشكل متصل من البداية إلى النهاية.
5. لا تعتبر كل رسالة أو مجموعة رسائل للشيخ سؤالًا مستقلًا.
6. اجمع الرسائل المتتابعة التي تشكل سؤالًا واحدًا أو جوابًا واحدًا.
7. اربط كل سؤال بالجواب الذي يخصه اعتمادًا على السياق الكامل.
8. إذا كانت هناك متابعة لنفس المسألة، أبقِها مرتبطة بالمناقشة الأصلية.
9. حافظ على النص العربي للشيخ، ولا تترجمه ولا تختصره.
10. احذف فقط ما هو واضح أنه غير متعلق بمادة الأسئلة والأجوبة من النسخة النهائية، مع الاحتفاظ به داخليًا إذا كان مفيدًا للمراجعة.
11. لا تخترع أي نص مفقود أو سؤالًا أو جوابًا.
12. إذا لم تكن متأكدًا من ارتباط سؤال بجواب، ضعه في فئة "يحتاج إلى مراجعة" بدل التخمين.
13. احتفظ بالتتبع الداخلي للرسائل الأصلية لكل سؤال وجواب.
14. لا تبدأ الآن في كتابة مقدمة الكتاب أو العنوان أو الفصول الموضوعية أو التنسيق النهائي للكتاب.
15. لا تنتقل إلى مرحلة الكتاب النهائي قبل إكمال استخراج الأرشيف كاملًا.

تقسيم العمل

استخدم دفعات متسلسلة، مثل:

Batch 001
Batch 002
Batch 003
...
حتى الوصول إلى آخر رسالة في الأرشيف.

والترقيم الداخلي للأسئلة يكون متصلًا:

السؤال 0001
السؤال 0002
السؤال 0003
...
وهكذا حتى نهاية الأرشيف.

لكل Q&A مؤكد، احتفظ داخليًا على الأقل بـ:

- رقم السؤال
- التاريخ
- اسم السائل إن كان واضحًا
- نص السؤال بالعربية
- نص جواب الشيخ بالعربية
- أرقام الرسائل الأصلية للسؤال
- أرقام الرسائل الأصلية للجواب
- حالة الاستخراج

مثلًا:

السؤال 0001
التاريخ: ...
السائل: ...
رسائل السؤال: ...
رسائل الجواب: ...
الحالة: مكتمل

الفئات

قسّم النتائج داخليًا إلى:

1. Q&A مؤكد
سؤال واضح وجواب الشيخ واضح.

2. يحتاج إلى مراجعة
هناك سؤال وجواب محتملان، لكن الارتباط بينهما غير مؤكد.

3. غير مرتبط
مثل الرسائل الإدارية، الشكر، الروابط، الإعلانات، رسائل الشيخ التي لا يظهر لها سؤال، والأسئلة التي لا يظهر لها جواب.

لا تحذف الفئتين الثانية والثالثة من البيانات الداخلية؛ فقد نحتاج إلى مراجعتها لاحقًا.

مهم جدًا

لا تحاول الوصول إلى رقم معين مثل 1,000 أو 2,000.

إذا كان العدد الحقيقي بعد الاستخراج الكامل 900، فهو 900.

إذا كان 1,500، فهو 1,500.

إذا كان 2,300، فهو 2,300.

الدقة أهم من العدد.

وبعد الانتهاء من الاستخراج الكامل

أريد منك أن تعطيني تقريرًا نهائيًا يوضح:

- إجمالي عدد رسائل WhatsApp التي تمت معالجتها.
- عدد Q&A المؤكدة.
- عدد Q&A التي تحتاج مراجعة.
- عدد الأسئلة التي لم تجد لها جوابًا.
- عدد أجوبة الشيخ التي لم تجد لها سؤالًا واضحًا.
- أول وآخر تاريخ تمت معالجته.
- آخر رقم سؤال تم الوصول إليه.
- أي أجزاء من الأرشيف لم تتم معالجتها، إن وجدت.

ولا تعتبر المشروع مكتملًا إلا إذا وصلت فعليًا إلى آخر رسالة في الأرشيف.

بعد اكتمال هذه المرحلة فقط، سننتقل إلى المرحلة التالية: مراجعة الاستخراج ثم تنظيم الأسئلة والأجوبة في أبواب وموضوعات للكتاب العربي.

ابدأ الآن.

[3:27 PM] **Dr. Moustafa Kamel مسجد الانصار:** تم التنفيذ على الأرشيف الكامل هذه المرة، وليس على عينة.

رجعت إلى ملف WhatsApp الأصلي، ومررت عليه من أول رسالة إلى آخر رسالة، ثم بنيت الاستخراج على وحدات الحوار بدل اعتبار كل رسالة سؤالًا مستقلًا.

النتيجة الحالية

* إجمالي رسائل التصدير: 8,015 رسالة.
* الفترة: 28 أبريل 2020 → 14 أغسطس 2026.
* عدد المشاركين/أسماء المرسلين: 500.
* الشيخ: Dr. Moustafa Kamel.
* عدد وحدات Q&A المستخرجة: 1,060.
* منها 809 وحدة واضحة بدرجة عالية.
* و251 وحدة موسومة «يحتاج إلى مراجعة».
* 520 رسالة للشيخ لم يظهر لها سؤال مرتبط مباشرة، فحُفظت في فئة مستقلة ولم تُرمى.
* آخر سؤال مستخرج هو السؤال 1060، ومصدره الرسائل 8000–8001، بتاريخ 11 أغسطس 2026.
* الرسائل بعد ذلك حتى 14 أغسطس تم فحصها أيضًا، لكنها في معظمها روابط، رسائل محذوفة، ملفات، مجاملات، أو رسائل إدارية/غير مرتبطة بـQ&A.

نقطة مهمة

لم أتعامل مع 1,060 على أنها «1,060 سؤالًا مؤكدًا»؛ الرقم يمثل وحدات نقاش Q&A مستخرجة. بعض الوحدات تحتوي أكثر من سؤال أو سؤال متابعة، ولذلك توجد 251 وحدة تحتاج مراجعة قبل اعتمادها نهائيًا.

كما حافظت على الحالات غير الواضحة بدل اختراع علاقة بين السؤال والجواب.

التتبع

لكل وحدة محفوظ:

* رقم السؤال.
* التاريخ.
* اسم السائل/السائلين.
* أرقام الرسائل الأصلية للسؤال.
* أرقام الرسائل الأصلية للجواب.
* النص العربي.
* حالة الاستخراج.
* والسياق السابق المحيط بالجواب عند الحاجة.

والـ13 سؤالًا القديمة أصبحت الآن جزءًا من الدفعة الأولى، وليست مجموعة منفصلة.

الدفعات

تم إنشاء 11 دفعة متسلسلة:

* Batch 001: الأسئلة 0001–0100
* Batch 002: 0101–0200
* …
* Batch 011: 1001–1060

كما أنشأت فهرسًا داخليًا لكل 8,015 رسالة حتى لا تختفي الرسائل التي لم تدخل الكتاب؛ وهي مصنفة إلى سؤال، جواب، سياق، جواب غير مرتبط، أو محتوى غير متعلق بالـQ&A.

تحميل جميع دفعات الاستخراج والبيانات الداخلية:

تحميل ملف الاستخراج الشامل ZIP⁠￼

وفي هذه المرحلة لن أبدأ الفصول أو العنوان أو المقدمة أو تنسيق الكتاب. الخطوة التالية المنطقية هي مراجعة الـ1,060 وحدة واختبار دقة الربط، خصوصًا الـ251 الموسومة «يحتاج إلى مراجعة» قبل اعتماد قاعدة البيانات النهائية.

[3:33 PM] **Dr. Moustafa Kamel مسجد الانصار:** [Document] WhatsApp Chat - أنت تسأل والشيخ يجيب.zip

---

## August 28, 2026

[12:49 PM] __[Call]__

[12:54 PM] __[Call]__

---

## August 29, 2026

[8:46 AM] **Dr. Moustafa Kamel مسجد الانصار:** [Document] a_general_introduction_to_islam_english.pdf

[8:47 AM] **Dr. Moustafa Kamel مسجد الانصار:** [Document] Islam-in-10-pages-a-brief-introduction-for-non-Muslims (1).pdf

[8:47 AM] **Dr. Moustafa Kamel مسجد الانصار:** [Document] Basic Beliefs of Islam.pdf

[8:48 AM] **Dr. Moustafa Kamel مسجد الانصار:** [Document] English_A_Simple_Guide_to_Islam.pdf

[8:49 AM] **Dr. Moustafa Kamel مسجد الانصار:** [Document] islam-guide.pdf

[8:49 AM] **Dr. Moustafa Kamel مسجد الانصار:** [Document] Islam-in-10-pages-a-brief-introduction-for-non-Muslims.pdf

[8:50 AM] **Dr. Moustafa Kamel مسجد الانصار:** [Document] Islam-Is.pdf

---

## September 4, 2026

[12:41 PM] **Dr. Moustafa Kamel مسجد الانصار:** رسائل للطلبة والدارسين في مستهل عام دراسي جديد  
الحمد لله رب العالمين والصلاة والسلام على المبعوث رحمة للعالمين وبعد،
فنحن على مقربة من عام دراسي جديد أو قد بدأ العام الدراسي في عدد من المدن والولايات، وإذا أردنا بحق أن ترسخ الوجود الإسلامي في الغرب وأن نجعل منه عنصر وصل حضاري وإثراء إنساني وإضافة حقيقية للمجتمعات الامريكية، وإذا أردنا بحق أن نحقق مقصد الشهادة على الناس قال تعالى: ﴿ وَكَذَلِكَ جَعَلْنَاكُمْ أُمَّةً وَسَطًا لِّتَكُونُوا شُهَدَاء عَلَى النَّاسِ وَيَكُونَ الرَّسُولُ عَلَيْكُمْ شَهِيدًا وَمَا جَعَلْنَا الْقِبْلَةَ الَّتِي كُنتَ عَلَيْهَا إِلَّا لِنَعْلَمَ مَن يَتَّبِعُ الرَّسُولَ مِمَّن يَنقَلِبُ عَلَى عَقِبَيْهِ وَإِن كَانَتْ لَكَبِيرَةً إِلَّا عَلَى الَّذِينَ هَدَى اللَّهُ وَمَا كَانَ اللَّهُ لِيُضِيعَ إِيمَانَكُمْ إِنَّ اللَّهَ بِالنَّاسِ لَرَؤُوفٌ رَّحِيم ﴾ [البقرة: 143]، فإن المدخل لكل ذلك هو أن نعتني بالعلم والتعليم وأن يكون من أبناء المسلمين الملتزمين دينيا العالم والمفكر والكاتب والمؤلف والشاعر والأديب والقانوني والطبيب والمهندس والسياسي والاقتصادي والعالم المتقن المتفنن في كل اختصاص وميدان وأن نرى من أولاد المسلمين من يحصد المراكز والجوائز العالمية في العلوم والابتكارات التي تعود بالخير والنفع على البشرية، فلابد للأبوين في كل أسرة أن يجعلوا تعليم أولادهم وتفوقهم الدراسي أولوية كبرى في حياتهم، وأن يستثمروا الفرص المتاحة لأولادهم في امريكا  والتي لا يحلم نظراؤهم خارجها بها، وأن الله تعالى منحهم دون جهد أو عمل نعمة كبرى هي الدراسة في أفضل الجامعات الأمريكية مع القرب من الأسرة والعائلة ودون اغتراب وهجرة كغيرهم، ودون العناء والمكابدة في دراسة اللغة وتدبير النفقات المالية كغيرهم، مع ضرورة التأكيد على رعاية الفروق الفردية والقدرات العقلية للأبناء فليسوا جميعا في مستوى واحد يجعلنا نتأمل منهم نتيجة واحدة وتفوقا تاما، كما يتعين علينا أن نتجنب الإكراه في العملية التعليمية والتربوية بكل صوره وأشكاله، سواء الإكراه على التخصص أو الإنجاز وإنما الرفق واللين والحكمة هو المنهج الواجب اتباعه مع الأبناء في ظل تضاعف التحديات وتعددها، وهذه جملة من الرسائل والتوصيات للطلبة والدراسين في مطلع عام دراسي جديد :  
1 - تجديد النية وعلو الهمة في طلب العلم : حتى يؤجر طالب العلم لابد أن يجدد نيته وأن يحدد قصده وهدفه وأن لا يقصر هدفه على الدنيوي دون استحضار للأخروي، فيستحضر أنه في عبادة وقربة الله عزوجل وتخيل هذا الأجر العظيم الذي يبشر به رسول الله طالب العلم خشية الله فيقول : " مَن سَلَكَ طريقًا يلتَمِسُ فِيهِ علمًا، سَهَّلَ اللَّهُ لَهُ طريقا إلى الجنَّةِ، وإنَّ المَلائِكَةَ لتضع أجنحتها لطالب العلم رضا بما يصنع وإنَّ العالم - ليستغفِرُ لَهُ مَن في السَّمواتِ ومن في الأرض، حتَّى الحيتان في الماء، وفضل العالم على العابد كفضل القمر على سائر الكواكب، وإنَّ العُلَماء ورثة الأنبياء إنَّ الأنبياء لم يورثوا دينارًا ولا درهما إِنَّما ورثوا العلم فمَن أخذَهُ أخذ بحظ وافر" الترمذي وأبو داوود وأحمد وابن ماجة عن أبي هريرة بسند صحيح، ثم عليك أن تطلب العلم بهمة عالية وصبر دائم فمن طلب الراحة فاتته الراحة، ومن أراد الراحة بعد انتهاء الدراسة لابد أن يتعب ويبذل أثناءها، كمن أراد الراحة في القبر والفوز بالجنة لابد أن يترك الراحة والكسل بالاجتهاد والمثابرة في الدنيا، وقد كان الأولون ينفقون شهورا وسنين عددا لجمع حديث عن رسول الله له أو تحقيق مسألة أو لقيا شيخ، وربما اقترض طالب العلم أو فقد ما يملك ليبلغ شيخا أو يحصل نسخة نادرة من كتاب واليوم سهل جدا الوصول إلى العلم وطرق العلماء والشيوخ باب الطلاب بالدراسة عن بعد، ورغم ذلك زهد الناس في العلم وضعفت هممهم على نحو غير مسبوق واستبدلوا لذة الطلب والتحصيل بالتصفح الشبكي في أمور وقضايا لا تفيدهم في دينهم أو دنياهم، وربما ثقلت موازينهم بأوزار وسيئات يحتاجون عمرا لمحوها وتبييض صحائفهم، لن أحدثكم عن نموذج لعلماء السلف المتقدمين وإنما عن عالم معاصر راحل هو البروفيسور فؤاد سزكين الذي سأله أستاذه المستشرق الألماني هلموت ريتر : كم ساعة تقرأ في اليوم؟ فأجابه سزكين بكل فخر 10 ساعات يوميا، رد عليه ريتر قائلاً: هذه الساعات لا تصنع منك عالما، وأخبره أن العلماء المسلمين الأوائل كانوا يعملون طوال اليوم ولا ينامون إلا ساعات قليلة، ومن يومها رفع سركين ساعات بحثه وقراءاته اليومية إلى 16 و 17 ساعة واستمر على هذا الجدول الصارم حتى تخطى التسعين من عمره ثم تحول هذا الأمر عنده إلى شرط أساسي عند طلابه وتلاميذه الذين يدرسون في معهده تاريخ العلوم العربية والإسلامية في فرانكفورت فكان يشترط على طلابه البقاء في المكتبة للقراءة والدراسة 10 إلى 12 ساعة يوميا بحد أدنى، فمن يصبر من أبنائنا اليوم على القراءة والدراسة هذه الساعات في انقطاع تام عن الشاشات؟!  
2 - احذر حرمان العلم بالمعصية : المعصية تُظلم القلب وتحرم صاحبها العلم وتسلبه التوفيق وتضعف قدرته العقلية على التركيز واستحضار المعلومات قال تعالى: ﴿ قُل لِّكُلِّ الْمُؤْمِنِينَ يَغُضُّوا مِنْ أَبْصَارِهِمْ وَيَحْفَظُوا فُرُوجَهُمْ ذَلِكَ أَزْكَى لَهُمْ إِنَّ اللَّهَ خَبِيرٌ بِمَا يَصْنَعُونَ ﴾ [النور: 30]، ومن معاني "أزكى" أنمى وأكمل لهم عقلا وقلبا، وقد أثبتت دراسات علمية حديثة أن إرسال البصر إلى المحرمات يقلل قدرة الدماغ على التركيز والذاكرة على الحفظ، ويُروى أن الإمام الشافعي شكا إلى شيخه وكيع بن الجراح سوء حفظه بعد قوته فأرشده إلى تجنب المعاصي وصاغها الشافعي في بيتين من الشعر قال:
شكوت إلى وكيع سوء حفظي فأرشدني إلى ترك المعاصي
وأخبرني بأن العلم نور ونور الله لا يهدى لعاصي
فاحذروا المعاصي أيها الطلبة خاصة إرسال النظر إلى ما حرم الله، واحرصوا على تجديد التوبة منها حتى تحفظوا عقولكم وقلوبكم.  
3- تجنب المشتتات والمشوشات: لا يُكتب لطالب علم التوفيق والفلاح إلا إذا استثمر وقته وتجنب الصوارف والشواغل والمشوشات والمشتتات ومن العبارات الرائقة قول الإمام الشافعي رحمه الله : " لو كلفت بصلة لما فهمت مسألة" رغم أن شراء البصلة لا يأخذ كثير وقت أو جهد لكنها ستشتت فكره وتضيع وقته فكيف بمن يقضي الساعات على الهواتف والشاشات فيقل تركيزه ويشتت انتباهه ولا يركز في دروسه وتعلمه، وهل يتعلم من يجيب له الذكاء الاصطناعي عن كل شيء في الدراسة ويحل له الواجبات المدرسية ؟!! وهذا مدرس  مسلم يقول بكل حسرة: لا تتخيل كيف تراجعت المستويات الدراسية للطلاب وتدنت الأخلاق بسبب الهواتف واعتمادهم على الذكاء الاصطناعي وليتهم يمنعون الهواتف تماما في مختلف المراحل الدراسية!! إنني أدعو طلبة العلم والدراسين إلى قراءة كتاب صفحات من صبر العلماء على شدائد العلم والتحصيل للشيخ عبد الفتاح أبو غدة ليتعلموا منه الصبر والمصابرة على طلب العلم وترك الكسل والراحة، ومما ذكره عن العالم العابد داود الطائي قوله :" ما بين مضغ الطعام وشرب الفتيت قراءة خمسين آية"، وإن الأوقات التي نضيعها فيما لا يفيد على الهواتف لو أنفقناها في التعلم وحفظ القرآن لأنجزنا الكثير مما لا نتخيل إنجازه في أعمارنا.  
حكاية الفيل والإمام مالك يشرح الموطأ وخروج الطلاب إلا الذي اصبح امام الدنيا يحيي بن يحيي الليثي وسأله الإمام لما لم تخرج قال اتيت  لأري مالك لا لأري الفيل 
4- صلاتك وبرك بأبويك سر تفوقك وفلاحك : اعلم أخي الطالب أن حفاظك على صلواتك خاصة صلاة الجمعة هي سر تفوقك وفلاحك وحصول البركة في وقتك وعملك فأحرص على أداء صلواتك في أوقاتها ولا تؤخرها إلا لعذر قاهر، وأبذل جهدا خاصا لتحافظ على صلاة الجمعة وتذكر حديث حبيبك : " من ترك ثلاث جمع تهاونا بها، طبعَ اللهُ على قلبه أبو داود والترمذي والنسائي بسند حسن عن أبي الجعد الضمري، ثم اعلم أن برك بأبويك وكسب رضاهما ودعائهما من أعظم أسباب الفلاح والتوفيق في حياتك كلها الدراسية والعملية، وكم من مقصر في دراسته جبر تقصيره برضا أبويه عنه وكم من فائق في دراسته قلت الأسباب عنده مقارنة بغيره كانت دعوة من أمه أعظم من كل سبب، وكم من طالب علم حرم التفوق لكن وسع الله عليه الرزق بسبب بره بأبويه، فاجعل شعارك هذه الآية الكريمة: ﴿ وَقَضَى رَبُّكَ أَلَّا تَعْبُدُواْ إِلَّا إِيَّاهُ وَبِالْوَالِدَيْنِ إِحْسَانًا إِمَّا يَبْلُغَنَّ عِندَكَ الْكِبَرَ أَحَدُهُمَا أَوْ كِلَاهُمَا فَلَا تَقُل لَّهُمَا أُفٍّ وَلَا تَنْهَرْهُمَا وَقُل لَّهُمَا قَوْلاً كَرِيمًا ﴾ [الإسراء: 23] .  
اللهم احفظ أولادنا وشبابنا وعلمهم ووفقهم في دراستهم وخلقهم بأخلاق الإسلام، وفرج الكرب عن أهلنا وإخواننا في غزة والسودان وكل مكان يا رب العالمين ، والحمد لله رب العالمين.

---

## September 18, 2026

[12:18 PM] __[Call]__

[1:07 PM] __[Call]__

[2:01 PM] **You:** السلام عليكم ورحمة الله وبركاته يا شيخنا، جزاكم الله خيرًا وبارك الله فيكم. أعتذر منكم يا شيخ عن عدم الرد على الاتصال، فقد كنت قد بدأت الخطبة في مسجد الرحمن في فونتانا، فلم أستطع أن أرد على الاتصال

[4:06 PM] **Dr. Moustafa Kamel مسجد الانصار:** وعليكم السلام ورحمة الله وبركاته 
ولا يهمك 
ربنا يتقبل منا ومنكم ويرفع قدرك ويثبتك على الحق

[8:26 PM] **You:** آمين و إياكم يا شيخنا

---

## September 20, 2026

[5:07 PM] **Dr. Moustafa Kamel مسجد الانصار:** السلام عليكم ورحمة الله وبركاته 
ازيك يا شيخ مصطفي يارب تكون بخير انت والاسره الكريمه بعد اذن حضرتك في جماعة بتوزع كتاب اسمة مورمن وعايزين يتكلموا معايا انا وابني هل امان اني اتكلم معاهم كنوع من المناظره و هل في ضرر علينا في انتظار نصيحة حضرتك وجزاك الله خيرا

[5:07 PM] **Dr. Moustafa Kamel مسجد الانصار:** السلام عليكم ورحمة الله وبركاته حبيبنا 
هذه رسالة وصلتني اليوم من الاخ سعيد سأعطيه رقم حضرتك

[6:43 PM] **You:** وعليكم السلام ورحمة الله وبركاته يا شيخنا، جزاكم الله خيرا وبارك الله فيكم، ونفع بكم وأحسن إليكم. نعم يا شيخ، أعطه رقمي ولا حرج إن شاء الله، وسأتواصل مع الأخ سعيد وأحاول أن أنصحه بما يناسبه، وأسأل الله أن يوفقنا وإياه للحق وينفع بنا.

[6:49 PM] **Dr. Moustafa Kamel مسجد الانصار:** الله يحفظكم

---

## September 23, 2026

[2:26 PM] **You:** السلام عليكم ورحمة الله وبركاتة يا شيخنا الحبيب، لو سمحت ممكن تبعتلي رقم يوسف؟ رقمه ضاع مني، وإن شاء الله أحب أن ينضم معنا في الدعوة.

[2:28 PM] **Dr. Moustafa Kamel مسجد الانصار:** [Contact: BEGIN:VCARD
VERSION:3.0
N:;Yusuf Moustafa Kamel;;;
FN:Yusuf Moustafa Kamel
TEL;type=CELL;type=VOICE;waid=17144880611:+1 (714) 488-0611
EMAIL;type=INTERNET;type=HOME:yusuf.kame@orangecrescent.com
X-SOCIALPROFILE;type=;x-user=‭(714) 488-0611‬:x-apple:%E2%80%AD(714)%20488-0611%E2%80%AC
END:VCARD]

[2:28 PM] **Dr. Moustafa Kamel مسجد الانصار:** وعليكم السلام ورحمة الله وبركاته

[4:22 PM] **You:** جزاك الله خيرا

[8:23 PM] **Dr. Moustafa Kamel مسجد الانصار:** واياكم حبيبنا

---

## September 25, 2026

[12:51 PM] **Dr. Moustafa Kamel مسجد الانصار:** 2303 S Manchester Ave
Anaheim, CA  92802
United States

[3:45 PM] __[Call]__

---

## October 2, 2026

[9:58 AM] **You:** السلام عليكم ورحمة الله وبركاته شيخنا، حياكم الله. أردت أن أعتذر منكم، لدي خطبة اليوم، ولذلك لن أستطيع الحضور للترجمة. جزاكم الله خيرا وبارك الله فيكم.

[9:59 AM] **You:** وبالمناسبة، لا أدري ما حكم تخصيص هذا اليوم بالاحتفال، ولكن يذكر أن في مثل هذا اليوم حرر صلاح الدين رحمه الله القدس، نسأل الله أن يحرر المسجد الأقصى وأن يرده إلى المسلمين.

[11:11 AM] **Dr. Moustafa Kamel مسجد الانصار:** وعليكم السلام ورحمة الله وبركاته حبيبنا 
وفقكم الله ورعاكم وسدد خطاكم وفتح لكم وتقبل منا ومنكم

[11:12 AM] **Dr. Moustafa Kamel مسجد الانصار:** هذا ليس تخصيص فأنت لم تقل هذه عبادة بل تذكير 
والله يقول 
وذكرهم بأيام الله. سورة إبراهيم

[11:13 AM] **You:** جزاك الله خيرا و فتح الله عليك و نفعنا بعلمك يا شيخنا الحبيب

[11:35 AM] **Dr. Moustafa Kamel مسجد الانصار:** واياكم حبيبنا 
وفقكم الله ورزقنا واياكم الإخلاص في القول والعمل

---

## October 3, 2026

[7:54 PM] **Dr. Moustafa Kamel مسجد الانصار:** +1 (763) 340-4271

[7:54 PM] **Dr. Moustafa Kamel مسجد الانصار:** الشيخ مصطفى

---

## October 4, 2026

[11:09 AM] **Dr. Moustafa Kamel مسجد الانصار:** السلام عليكم ورحمة الله وبركاته حبيبنا 
عندي عقد نكاح اليوم واحتاج مترجم  فهل عندك وقت تقابلني اليوم في صلاة العصر بالمسجد الساعة 4:15
جزاكم الله خيرا

[2:00 PM] **You:** عليكم السلام ورحمة الله وبركاته شيخنا الحبيب

ده إحنا نفضلك يا شيخ حتى لو ورانا حاجة، وإن شاء الله أحضركم اليوم في صلاة العصر بمسجد الأنصار الساعة 4:15 ونلتقي هناك بإذن الله.

ونعتذر عن التأخر في الرد، كنت مشغولا. وجزاكم الله خيرا وبارك فيكم.

[2:40 PM] **Dr. Moustafa Kamel مسجد الانصار:** ولا يهمك 
نراكم على خير

[2:54 PM] **You:** على نفس الموعد إن شاء الله  4:15؟

[3:20 PM] **Dr. Moustafa Kamel مسجد الانصار:** باذن الله نصلي العصر بالمسجد ونخرج

[4:11 PM] **You:** أبشر يا شيخ إن شاء الله. أنا في الطريق ولكن قد أتأخر خمسة وعشر دقائق و نسأل الله السلامة

---

## October 5, 2026

[8:48 PM] **Dr. Moustafa Kamel مسجد الانصار:** 1863 S Eileen Dr Anaheim CA 92802

[9:00 PM] **You:** جزاك الله خيرا يا شيخنا

[9:03 PM] **Dr. Moustafa Kamel مسجد الانصار:** واياكم حبيبنا

---

## October 7, 2026

[10:41 AM] **Dr. Moustafa Kamel مسجد الانصار:** السلام عليكم شيخنا الفاضل. أرجو من الله عز وجل ان تكون انت والاسره بالف خير.

ارجوا من حضرتك ان توصلني بأحد الإخوه القادرين على إعطاء خطبتي الجمعة
 في اوكتوبر 16 & 23 في مسجد جمال الدين الأفغاني  وجزاكم الله خير الجزاء.
اخوكم يوسف ابو باسل

[10:42 AM] **Dr. Moustafa Kamel مسجد الانصار:** السلام عليكم ورحمة الله وبركاته حبيبنا الغالي 
أعطت رقم حضرتك للأخ ابا باسل ليكلمك علي الخطب أعلاه

[10:42 AM] **Dr. Moustafa Kamel مسجد الانصار:** هدا رقمه

[10:42 AM] **Dr. Moustafa Kamel مسجد الانصار:** +1 (513) 616-3462

[10:58 AM] **You:** عليكم السلام ورحمة الله وبركاته، شيخنا الحبيب، حفظكم الله وبارك فيكم.

تحدثت مع أخينا أبي باسل بخصوص خطبة الجمعة (16 و23)، وقد اتصل بي، وإن شاء الله سأعطيهما له بإذن الله.

فجزاكم الله خيرا، وأثابكم الله وبارك فيكم، وأسأل الله أن يجزيكم عنا خير الجزاء.

ونأمل أن نكون عند حسن ظنكم، شيخنا الحبيب، ونراكم على السادسة إن أذن الله الليلة.

جزاكم الله خيرا وبارك فيكم.

[11:59 AM] **Dr. Moustafa Kamel مسجد الانصار:** وفقكم الله وحفظكم وفتح لكم أبواب الخير والعلم والبركة

[12:29 PM] **You:** آمين يا رب و إياكم شيخنا

[12:34 PM] **Dr. Moustafa Kamel مسجد الانصار:** المغرب 6:30
وميشن فياهو. مسحد الطريق بياخذ 40 دقيقة 
فما رأيك نخرج الساعة 5:40 دقيقة 
لان هذا الوقت ايضا زحام شديد

[1:10 PM] **You:** أرى ما ترون يا شيخ، أبشر إن شاء الله، أكون عندكم الساعة 5:40 بإذن الله عز وجل.

[3:00 PM] **Dr. Moustafa Kamel مسجد الانصار:** الله يبارك فيكم

---

## October 8, 2026

[2:46 PM] **Dr. Moustafa Kamel مسجد الانصار:** السلام عليكم ورحمة الله وبركاته حبيبنا 
ادعوا الله أن تكونوا بخير وعافية 
بقول حضرتك 
اليوتوب بيرسل لي تحذيرات بسبب الدعاء على الاحتلال المجرم وشكلهم ناويين يحذفوها 
فهل ممكن تساعدني في تنزيلها على فلاشة او شيء يحفظ ما عليها لعلنا نعيد تنزيلها مرة اخرة خاصة وأنهم يبحثون في القديم 
جزاكم الله خيرا

[3:03 PM] **You:** وعليكم السلام ورحمة الله وبركاته، شيخنا الحبيب، حفظكم الله وبارك فيكم.

أبشر يا شيخ، إن شاء الله أساعدكم في حفظ الفيديوهات. فقط أرسلوا لي الفيديوهات التي تريدون تحميلها، أو أخبروني أين أجدها، وهل لديكم فلاشة USB أم تريدونني أن أحضر واحدة؟

جزاكم الله خيرا، وحفظكم الله من كل سوء

[4:03 PM] **Dr. Moustafa Kamel مسجد الانصار:** وعندي هارد الذي ننزل عليه لما ارجع ان شاء الله الأحد

---

## October 9, 2026

[4:20 AM] **Dr. Moustafa Kamel مسجد الانصار:** The Qur'an is Light and Guidance
Praise be to Allah, Lord of the Worlds, and peace and blessings be upon the one sent as a mercy to the worlds. To proceed:  
Muslims in the West live in a renewed state of fear and anxiety over their religion and identity, with its causes renewing and multiplying day after day. They feel the responsibility of global conveyance and clear proclamation of Islam due to living among a non-Muslim majority. Furthermore, they live in a highly materialistic environment that leads to spiritual dryness, hardness of the heart, and the accumulation of rust and barriers upon it.  
These three concerns represent central issues in the life of a Muslim in the West; he is responsible for preserving his faith and the faith of his dependents, he carries a missionary responsibility toward non-Muslims, and it is a door of great reward and virtue opened to every Muslim that must be seized. If the heart hardens and the spirit dries up, daily admonitions and acts of worship will not suffice nor achieve their purpose and impact in a Muslim's life and the Hereafter. The single, comprehensive answer to these three issues—and the disperser of those worries—is the Holy Qur'an.  
The Holy Qur'an is the primary means of steadfastness upon the faith. Allah Almighty says: "And those who disbelieve say, 'Why was the Qur'an not revealed to him all at once?' Thus [it is] that We may strengthen thereby your heart. And We have recited it with distinct recitation." [Al-Furqan: 32]. And Allah Almighty says: "Say, [O Muhammad], the Holy Spirit has brought it down from your Lord in truth to make firm those who believe and as guidance and good tidings for the Muslims." [An-Nahl: 102]. Khuwailid bin 'Amr reported that the Messenger of Allah ﷺ came out to us and said: "Rejoice! Rejoice! Do you not bear witness that there is no deity worthy of worship except Allah and that I am the Messenger of Allah?" They said: "Yes." He said: "Indeed, this Qur'an is a rope, one end of which is in the hand of Allah and the other end is in your hands. So hold fast to it, for you will never go astray nor be destroyed after it ever." (Reported by Ibn Hibban and Ibn Abi Shaybah with an authentic chain).  
We in the West are part of this reality. According to 2021 statistics, the number of Muslims in the West has reached a significant population, and many are immigrants and children of immigrants. More than a quarter of them are under fifteen years old; meaning we are facing a rising generation moving between Arabic and local Western languages, with their consciousness formed in school, the street, and screens more than at home. In the West, there is a renewed public debate around the presence of religion in the public sphere, and we have tasted the pain of hatred through attacks on mosques that claimed the lives of worshippers—may Allah have mercy on them and count them among the martyrs. There is no steadfastness for our children and no tranquility for us except through the light of the Qur'an, and no honorable presence for us in our society except by being ambassadors for the Qur'an through good manners, excellence, and good neighborliness.  
In the previous Friday sermon, we addressed "Positive Participation and the Responsibility of a Muslim in the Western Reality". Now that the elections have passed, does participation end with their conclusion? Not at all; participation that begins before elections continues after them, and the vote cast as a trust is followed by work and building. Allah Almighty says: "And say, 'Work, for Allah will see your work, and [so will] His Messenger and the believers.'" [At-Tawbah: 105]. The greatest thing we can work on after elections is building the human being who participates effectively: a generation proud of its faith and serving its society. This can only be crafted by the Qur'an, which instills trustworthiness, justice, and excellence. The Qur'an is the bridge between our call for an influential and responsible presence and what we wish to build in terms of steadfastness and ambassadorship for the Qur'an. Let us connect after elections with those chosen to represent the people with etiquette and order, introduce them to our mosques and Qur'anic schools, and show their role in raising our children on honesty, trustworthiness, respect for the law, and good neighborliness. Let us convey to people our practice of the Qur'an before our words about it.  
The Holy Qur'an was the primary direct reason for the guidance of prominent Companions and leaders of disbelief to Islam. Umar ibn Al-Khattab (may Allah be pleased with him) went out one day carrying his sword intending to reach the Prophet ﷺ, but when he heard the beginning of Surah Taha, his heart softened and Allah opened his chest to Islam (as mentioned in biography books). Jubair ibn Mut'im (may Allah be pleased with him) came to the Prophet ﷺ regarding the captives of Badr while he was still a polytheist, and heard him reciting Surah At-Tur in the Maghrib prayer. He said: "When he reached this verse: 'Or were they created by nothing, or were they the creators? Or did they create the heavens and the earth? Rather, they are not certain.' [At-Tur: 35-36], my heart was about to fly." (Reported by Al-Bukhari).  
It was also the reason for changing the hearts and minds of major Western philosophers and thinkers whom Allah guided to Islam through a verse in Allah's Book: such as Jeffrey Lang, who accepted Islam due to the question of stewardship in Surah Al-Baqarah: "And [mention, O Muhammad], when your Lord said to the angels, 'Indeed, I will make upon the earth a successive authority.' They said, 'Will You place upon it one who causes corruption therein and sheds blood, while we declare Your praise and sanctify You?' Allah said, 'Indeed, I know that which you do not know.'" [Al-Baqarah: 30]; Murad Hofmann, who accepted Islam due to a verse repeated 5 times in the Holy Qur'an: "And no bearer of burdens shall bear the burden of another." [Al-An'am: 164]; and Muhammad Asad, who accepted Islam due to Allah's saying: "Competition in worldly increase diverts you." [At-Takathur: 1].  
The Qur'an is the primary and ultimate tool for clear proclamation of Islam. Furthermore, it is the greatest tool for purification, softening the heart, removing its hardness, and erasing its rust. Allah Almighty said regarding the impact of the Qur'an on non-Muslims: "And when they hear what has been revealed to the Messenger, you see their eyes overflowing with tears because of what they have recognized of the truth. They say, 'Our Lord, we have believed, so register us among the witnesses.'" [Al-Ma'idah: 83]. Allah Almighty also explained that a believer's heart is even more deserving of being impacted by the Qur'an than a mountain humbling and splitting apart out of fear of Allah: "If We had sent down this Qur'an upon a mountain, you would have seen it humbled and coming apart from fear of Allah. And these examples We present to the people that perhaps they will give thought." [Al-Hashr: 21]. He also stated that the Qur'an is the cause of humility and softness of the heart, while distance from it causes hardness: "Has the time not come for those who have believed that their hearts should become humbly submissive at the remembrance of Allah and what has come down of the truth and that they not be like those who were given the Scripture before, and a long period passed over them so their hearts hardened; and many of them are defiantly disobedient." [Al-Hadid: 16].  
The Qur'an is the book of guidance for both Muslims and non-Muslims. Allah Almighty says: "The month of Ramadhan [is that] in which was revealed the Qur'an, a guidance for the people and clear proofs of guidance and criterion..." [Al-Baqarah: 185]. And He says: "Indeed, this Qur'an guides to that which is most suitable and gives good tidings to the believers who do righteous deeds that they will have a great reward." [Al-Isra: 9]. And He says regarding those hostile to the message: "And if any one of the polytheists seeks your protection, then grant him protection so that he may hear the words of Allah..." [At-Tawbah: 6].  
How worthy is it for us to let those around us hear the Qur'an and present it well to them! Here are insights to activate the Qur'an as a book of guidance in our reality in the West:  
1- Caring for the Qur'an in Our Homes:
Whoever wants to make their children love the Qur'an must be a good role model for them in their relationship with the Holy Qur'an—in recitation, memorization, reflection, and embodying its morals. Children should see parents browsing the Qur'an more than browsing phones and screens. We must sacrifice time and money for our children to connect them to Allah's Book, make them love memorizing and reciting it, remain patient with them, pray for them, and benefit from others' experiences in teaching their children the Qur'an.  
Some have taken a break with their children for a year or two in an Arab country to memorize the Qur'an and obtain an authorization (Ijazah). Others maintained a regular family Qur'an circle at home that became a means for all family members to memorize the Holy Qur'an over the years. In some cases, the mother alone was the reason all her children memorized the Qur'an. Others decided to disconnect from their phones and not return until memorizing the Qur'an, returning as memorizers after a few months. How many young men and women born and raised in the West have memorized the Qur'an and obtained Ijazah through sincerity of purpose and high ambition!  
Our Lord Almighty commanded us to protect our families: "O you who have believed, protect yourselves and your families from a Fire..." [At-Tahrim: 6], and the greatest thing to protect them with is the light of the Qur'an. The Prophet ﷺ said: "Whoever reads the Qur'an and acts upon what is in it, his parents will be clothed with a crown on the Day of Resurrection whose light is better than the light of the sun in the houses of this world if it were among you. So what do you think of the one who acted upon this?" (Reported by Abu Dawood and classed as Hasan by Al-Albani). Imam Al-Shafi'i (may Allah have mercy on him) grew up as an orphan under his mother's care, memorized the Qur'an at seven years old, and memorized Al-Muwatta at ten, which laid the foundation for his leadership in knowledge.  
The beginning does not need to be huge; a daily portion—even a single page—and a short family session after Maghrib prayer will accomplish over years what wishes cannot. How long and cold are the Western winters! Let us make their long nights warm Qur'anic gatherings in our homes, and let us make school holidays and summer a season for memorization and revision.  
2- Upbringing Upon the Companionship of the Qur'an:
Many authentic ahadith from the Messenger of Allah ﷺ describe the relationship with the Qur'an as companionship, a companion, and friendship, which requires constant adherence, love, and non-interruption; such as his saying ﷺ: "Read the Qur'an, for it will come on the Day of Resurrection as an intercessor for its companions." (Reported by Muslim). Yet, among the ahadith stating the reward of reciting the Qur'an and describing it as companionship, I have not found a narration as beautiful, grand, and clear as the hadith of Buraidah ibn Al-Husaib Al-Aslami (may Allah be pleased with him) that the Messenger of Allah ﷺ said: "Indeed, the Qur'an will meet its companion on the Day of Resurrection when his grave splits open, like a pale man, saying to him: 'Do you know me?' He will say: 'I do not know you.' It will say: 'I am your companion, the Qur'an, which kept you thirsty in the midday heat and kept you awake at night. Every trader is behind his trade, and today you are behind every trade.' He will be given sovereignty in his right hand and eternity in his left, a crown of dignity will be placed on his head, and his parents will be clothed in two garments the likes of which the people of the world could never afford. They will say: 'Why have we been clothed in this?' It will be said: 'Because of your child's taking up of the Qur'an.' Then it will be said: 'Read and ascend through the degrees and rooms of Paradise,' and he will continue ascending as long as he reads, whether rapidly or with measured recitation." (Reported by Al-Darimi, Al-Bayhaqi, and Ahmad with a good chain).  
Raising children on the companionship of the Qur'an must start from a young age, even from the moment of thinking about marriage and seeking a partner from the people of the Qur'an. Jibreel (peace be upon him) used to study the Qur'an with the Prophet ﷺ every night in Ramadan (Agreed upon)—this is true companionship. The Prophet ﷺ said: "The example of a believer who recites the Qur'an is like that of a citron: its taste is delicious and its smell is pleasant. And the example of a believer who does not recite the Qur'an is like that of a date: its taste is sweet and it has no smell." (Agreed upon). He ﷺ also said: "It will be said to the companion of the Qur'an: 'Read and ascend, and recite as you used to recite in the world, for your status will be at the last verse you recite.'" (Reported by Abu Dawood and At-Tirmidhi, who said it is Hasan Sahih).  
Conversely, our Lord warned against abandoning His Book: "And the Messenger has said, 'O my Lord, indeed my people have taken this Qur'an as [a thing] abandoned.'" [Al-Furqan: 30]. Abandoning it is not merely leaving its recitation, but leaving reflection and action upon it. Allah admonished locked hearts, saying: "Then do they not reflect upon the Qur'an, or are there locks upon [their] hearts?" [Muhammad: 24].  
3- Caring for the Arabic Language and Facilitating the Qur'an for Non-Arabs:
We need to give utmost care to the Arabic language, especially for those of Arab origin, because mastering it is easy and accessible compared to those of non-Arab origin, and because it facilitates memorizing, understanding, properly reflecting upon, and acting according to the Qur'an. Allah Almighty says: "In a clear Arabic language." [Ash-Shu'ara: 195]. It is also a key identity marker for Muslims in the West.  
Parents and educators in the West almost unanimously agree that one of the biggest challenges facing the new generation of Muslim youth in the West is the Arabic language. If the new generations' connection to Arabic weakens, their connection to the Qur'an weakens, and their understanding of Islamic concepts and principles from pure sources becomes distorted. Allah Almighty says: "Indeed, We have sent it down as an Arabic Qur'an that you might understand." [Yusuf: 2], and says: "And thus We have sent it down as an Arabic Qur'an and have diversified therein the warnings that perhaps they will become righteous or it may cause them remembrance." [Taha: 113].  
However, we also need approaches, experiences, and developments to present and teach the Qur'an to non-Arabs. We must develop the mission and work of Qur'anic schools, moving from rote memorization to memorization centered on comprehension and interaction with the Qur'an. We must accommodate the unique needs of those who do not know Arabic in the West within Qur'anic schools to fortify youth through the Qur'an against doubts and desires, renewing and firming faith in their hearts.  
It was reported that Umar (may Allah be pleased with him) said: "Learn Arabic, for it is part of your religion." Shaykh al-Islam Ibn Taymiyyah said: "The Arabic language itself is part of the religion, and knowing it is an obligation.". This does not exclude non-Arabs; scholars of non-Arab origin, such as Al-Bukhari and Sibawayh (may Allah have mercy on them), served the Qur'an and the Arabic language immensely. Allah made His Book easy, saying: "And We have certainly made the Qur'an easy for remembrance, so is there any who will remember?" [Al-Qamar: 17]. The Prophet ﷺ said: "The one who is skilled in the Qur'an will be with the noble and obedient scribes (angels), and the one who recites the Qur'an and falters in it, finding it difficult, will have a double reward." (Agreed upon). Difficulty in pronunciation should not stop anyone from starting; whoever struggles and perseveres receives a double reward.  
In the West, where local Western languages are the media of school, work, media, and global communication, we must present the Qur'an, its meanings, and the Seerah of the Prophet ﷺ in local languages for children, new converts, and anyone who has not mastered Arabic, so they do not assume the Qur'an is exclusive to those fluent in it. Allah Almighty says: "And We did not send any messenger except [speaking] in the language of his people to state clearly for them..." [Ibrahim: 4]. Among the purposes of clear communication is that people understand what is recited to them.  
4- Caring for Qur'anic Schools and Activities:
There are many Qur'anic schools and activities in the West. These schools require development, effort, dedication, and specialization to fulfill their mission and achieve their purpose of establishing the new generation upon the faith and connecting them to Allah's Book. It is the duty of Muslims to support these Qur'anic schools and activities with time and money, establish endowments (Awqaf) to serve the Qur'an, encourage their children to participate, sponsor Qur'an teachers, and offer all forms of support through prayers or kind words.  
It is our duty that our mosques and centers host regular circles, competitions, and summer Qur'an programs. Participate in supporting them, and encourage the memorizers and participants. Glad tidings to whoever contributes their time, effort, and wealth to revive and serve Allah's Book! This was how Islam began; Ubadah ibn Al-Samit (may Allah be pleased with him) used to teach the people of Al-Suffah in the Prophet's Mosque reading and the Qur'an (Reported by Abu Dawood and Ibn Majah). Mosques were schools for the Qur'an before anything else.  
In our current reality, school hours, sports practices, long distances, and cold winter weather crowd our children's time—these are real constraints. Let us cooperate to organize local neighborhood circles, online sessions, and flexible times. With ongoing legal and media debates in the West regarding expressions of religiosity in public spaces, our need increases for strong mosques and Qur'anic schools that teach our children the Qur'an along with values of honesty, trustworthiness, respect for the law, and good neighborliness. This produces a generation proud of its faith and serving its society. There is no contradiction between holding fast to the Qur'an and good citizenship; rather, the Qur'an is the greatest driver toward it.  
5- The Virtue of Learning the Qur'an, Teaching It, and Spreading It:
Allah praised the people of the Qur'an, saying: "Indeed, those who recite the Book of Allah and establish prayer and spend [in His cause] out of what We have provided them, secretly and publicly, can expect a transaction that will never perish." [Fatir: 29]. The Prophet ﷺ said: "The best among you are those who learn the Qur'an and teach it." (Reported by Al-Bukhari). He ﷺ also said: "No group gathers in one of the houses of Allah, reciting the Book of Allah and studying it among themselves, except that tranquility descends upon them, mercy covers them, angels surround them, and Allah mentions them to those near Him." (Reported by Muslim). He ﷺ said: "Whoever recites a letter from the Book of Allah will receive a good deed for it, and a good deed receives a tenfold reward." (Reported by At-Tirmidhi, who said it is Hasan Sahih).  
As for spreading it and inviting people through it, Allah Almighty says: "And who is better in speech than one who invites to Allah and does righteousness and says, 'Indeed, I am of the Muslims'?" [Fussilat: 33]. He said regarding the Qur'an: "And strive against them with the Qur'an a great striving." [Al-Furqan: 52], meaning strive against them through the Qur'an. The Prophet ﷺ said: "Convey from me, even if it is a single verse." (Reported by Al-Bukhari). He ﷺ said: "Whoever guides to a good deed will have a reward similar to the one who does it." (Reported by Muslim). He ﷺ also said: "When a man dies, his deeds come to an end except for three: an ongoing charity, beneficial knowledge, or a righteous child who prays for him." (Reported by Muslim). Whoever teaches the Qur'an combines all three.  
Among historical examples: Mus'ab ibn 'Umair (may Allah be pleased with him) was sent by the Prophet ﷺ to Madinah to recite the Qur'an to its people and teach them Islam. As'ad ibn Zurarah, Usaid ibn Hudair, and Sa'd ibn Mu'adh (may Allah be pleased with them) accepted Islam upon hearing the Qur'an, followed by the tribe of Banu 'Abd al-Ashhas. A single teacher was the cause for opening an entire city without fighting. Furthermore, seventy Companions known as "Al-Qurra" (the Reciters) were sent by the Prophet ﷺ to teach people, but were treacherously killed at the Well of Ma'unah, causing him deep sorrow (Reported by Al-Bukhari and Muslim). How elevated is the status of a Qur'an teacher with Allah and His Messenger!  
In our reality today, how many non-Muslims in the West had their first encounter with Islam through a translation of the Qur'an's meanings, a verse they heard, or a Muslim neighbor who treated them well and recited what was easy for them! Let us be that neighbor and that verse.  
6- The Efforts of Qur'anic Institutions and Our Duty to Support Them:
The Ummah has not abandoned its Lord's Book. Institutions and organizations have been established globally to serve the Qur'an through printing, translation, memorization, and teaching. Among them: the King Fahd Complex for the Printing of the Holy Qur'an in Madinah, which prints the Qur'an and translations of its meanings in dozens of languages, distributing them to pilgrims and Islamic centers worldwide. Also, charitable Qur'an memorization societies, Qira'at centers, Al-Azhar Al-Sharif with its institutes, and Ministries of Awqaf across Islamic lands that have graduated thousands of memorizers and reciters.  
Among them are international Qur'an competitions and awards, such as the King Abdulaziz International Holy Qur'an Competition in Makkah and the Dubai International Holy Qur'an Award, which motivate youth worldwide to memorize Allah's Book.  
In the West, there are hundreds of mosques, Islamic centers, Qur'anic schools, memorization circles, and weekend schools across various cities. There are summer competitions and programs organized by centers to encourage youth, as well as platforms and apps connecting learners with teachers wherever they are. May Allah reward those running these institutions with the best reward!  
These institutions cannot operate without public support. Allah Almighty says: "And cooperate in righteousness and piety..." [Al-Ma'idah: 2], and says: "And whatever good you put forward for yourselves - you will find it with Allah. It is better and greater in reward." [Al-Muzzammil: 20]. The Prophet ﷺ said: "Allah continues to help a servant as long as the servant helps his brother." (Reported by Muslim).  
Cooperate with them through regular donations, even if small; endow property for printing copies of the Qur'an and sponsoring teachers; register your children and attend events; volunteer your time and skills; spread their news and encourage memorizers and teachers; and donate through registered charities that issue official tax receipts. Whatever is spent serving the Qur'an is never small; it is a trade that will never perish.  
Supplication (Dua):
O Allah, have mercy on us through the Qur'an and make it for us a leader, light, guidance, and mercy. O Allah, remind us of what we have forgotten from it, teach us what we are ignorant of, grant us its recitation during the hours of the night and ends of the day, and make it a proof for us and not against us. O Allah, make us among the people of the Qur'an who are Your people and Your special ones, and bless everyone who teaches it, spreads it, and supports it. O Allah, protect Muslims in the West, make our sons and daughters steadfast upon Your religion, grant us good neighborliness and true citizenship, and protect our mosques, centers, and Qur'anic schools from all evil.  
O Allah, grant success to those appointed over affairs after elections to act with justice, trustworthiness, and service to the people, and make us partners in goodness through the Qur'an and acting upon it.  
O Allah, make the Great Qur'an the spring of our hearts, the light of our chests, and the departure of our worries and sorrows. O Allah, be a supporter, helper, protector, and victor for our families and brothers in Palestine, Yemen, Sudan, and everywhere. Praise be to Allah, Lord of the Worlds.

[6:42 AM] **You:** ما شاء الله، خطبة جميلة حفظكم الله و أعانكم على فعل الخير

[6:44 AM] **You:**
> _Dr. Moustafa Kamel مسجد الانصار: وعندي هارد الذي ننزل عليه لما ارجع ان شاء الله الأحد_
أبشر يا شيخ، إن شاء الله. إذا سمحتم، يكون ذلك بعد يوم الاثنين، فلدي مقابلة عمل يوم الاثنين، فأسألكم الدعاء بالتوفيق والتيسير. وبعدها في أي يوم يناسبكم بإذن الله.
جزاكم الله خيرا وبارك الله فيكم.

[7:11 AM] **Dr. Moustafa Kamel مسجد الانصار:** اسال الله لكم التوفيق والتيسير

---

## October 12, 2026

[6:33 PM] **You:** السلام عليكم ورحمة الله وبركاته شيخنا الحبيب 

هل هناك درس الليلة بإذن الله؟

[8:30 PM] **Dr. Moustafa Kamel مسجد الانصار:** [Image]

---

## October 13, 2026

[12:11 PM] __[Call]__

[12:13 PM] **You:** السلام عليكم ورحمة الله وبركاته شيخنا الحبيب
 أنا في الطريق إليكم إن شاء الله، وباقي لي نحو ثلث ساعة للوصول.

[12:25 PM] **Dr. Moustafa Kamel مسجد الانصار:** وعليكم السلام ورحمة الله وبركاته 
تشرف

[4:18 PM] **Dr. Moustafa Kamel مسجد الانصار:** [Document] #12- Series of -Proud To Be Muslims-.pdf

[4:18 PM] **You:** جزاكم الله خيرا وبارك فيكم

[5:23 PM] **Dr. Moustafa Kamel مسجد الانصار:** واياكم

---

## October 16, 2026

[10:12 AM] **You:** السلام عليكم ورحمة الله وبركاته شيخنا الحبيب، بارك الله فيكم.

أثناء تجهيز أرشفة القناة وحفظ جميع المقاطع والدروس، ظهرت لي ثلاثة أمور أحتاج إلى مشورتكم فيها قبل أن أبدأ بتحميل الملفات:

١. القرص الصلب الأول: سعته ٤ تيرابايت، لكنه مهيأ للعمل مع أجهزة Mac، ولذلك لا يستطيع Windows قراءته ويطلب مني تهيئته(formatting). ولا أريد تهيئته قبل التأكد من نظامه وما إذا كانت عليه ملفات نحتاج إلى الاحتفاظ بها.

٢. القرص الصلب الثاني: سعته ٤ تيرابايت، والمتاح فيه حاليا نحو ١٫٨ تيرابايت فقط. وبحسب التقدير الأولي، قد تحتاج أرشفة القناة كاملة إلى مساحة أكبر من ذلك، وربما تصل إلى نحو ٢٫٥ تيرابايت أو أكثر، بحسب جودة الملفات المتاحة. وهذا تقدير مبدئي وليس قياسا فعليا بعد.

٣. الفيروسات: عند فحص القرص الثاني ببرنامج AVG، اكتشف البرنامج أكثر من ٩٠ ملفا صنفها على أنها برمجيات ضارة، ونقلها إلى الحجر الصحي. لذلك أريد التأكد من سلامة القرص قبل الاعتماد عليه في حفظ الأرشيف.

فأحببت أن أستشيركم قبل اتخاذ أي خطوة: هل ترون أن أحضر القرص المهيأ للـ Mac إلى جهازكم وأتحقق من محتوياته وأفضل طريقة للاستفادة منه، أم تفضّلون أن نستخدم أقراصًا أخرى مناسبة لنظام Windows وبمساحة كافية لحفظ الأرشيف ونسخة احتياطية مستقلة؟

ولا أريد تهيئة أي قرص أو حذف أي ملفات قبل التأكد من عدم ضياع شيء مهم، كما لن أبدأ بالتحميل الكامل قبل التأكد من توفر مساحة كافية وسليمة.

 و إذا سمحت ارسلت لي الgmail & password
 للyoutube مرة أخرى

جزاكم الله خيرا، وبارك في علمكم ونفع بكم.

[10:15 AM] **Dr. Moustafa Kamel مسجد الانصار:** وعليكم السلام ورحمة الله وبركاته حبيبنا
الثاني ممكن تمسحه وتضع عليه الفناة 
ولكن طابق بينهما فان كان في الثاني شيء زيادة إذا سمحتانقله للأول ماك
جزاكم الله خيرا

[10:22 AM] **You:** جزاكم الله خيرا شيخنا. القرص الأول مكتوب عليه Only Mac، ولا يستطيع جهازي قراءته إلا إذا قمت بتهيئته format، وهذا قد يمسح ما عليه. فهل آتي به إلى جهاز Mac عندكم لنقل الملفات إليه، أم تأذنون لي بتهيئته؟

[10:45 AM] **Dr. Moustafa Kamel مسجد الانصار:** واياكم 
أتفضل البيت بيتك

[10:45 AM] **Dr. Moustafa Kamel مسجد الانصار:** عندك خطبة اليوم 
ولا ستترجم

[11:36 AM] **You:** لا في خطبة إن شاء الله

[11:37 AM] **Dr. Moustafa Kamel مسجد الانصار:** عندك خطبة

[11:37 AM] **You:** نعم إن شاء الله

[11:37 AM] **Dr. Moustafa Kamel مسجد الانصار:** وفقكم الله وفتح عليكم أبواب الخير والقبول

[11:37 AM] **You:** آمين يارب وإياكم و جزاكم الله خيرا

[11:38 AM] **Dr. Moustafa Kamel مسجد الانصار:** واياكم

---

## October 17, 2026

[9:19 PM] **You:** السلام عليكم ورحمة الله وبركاته شيخنا الحبيب 
ممكن ترسل الgmail & password 
لل youtube

[9:23 PM] **Dr. Moustafa Kamel مسجد الانصار:** هدا رقم غسان هو الذي يعرف 
(714) 710-0751

[9:24 PM] **Dr. Moustafa Kamel مسجد الانصار:** واذا اذكر فهو
Yusuf@2007

[9:24 PM] **Dr. Moustafa Kamel مسجد الانصار:** وعليكم السلام ورحمة الله وبركاته حبيبنا

[9:26 PM] **You:** جزاك الله خيرا، اشتقنا لك اليوم، نسأل الله أن تكون بخير

[9:36 PM] **Dr. Moustafa Kamel مسجد الانصار:** واياكم 
نراكم قريبا ان شاء الله 
ربنا يحفظكم

[9:48 PM] **You:** بإذن الله تعالى و إياكم

---

## October 18, 2026

[12:18 PM] **You:** السلام عليكم ورحمة الله وبركاته شيخنا 
ممكن إذا سمحت ترسلي الرقم الذي يظهر على الipad

[12:19 PM] **Dr. Moustafa Kamel مسجد الانصار:** وعليكم السلام ورحمة الله وبركاته حبيبنا

[12:19 PM] **Dr. Moustafa Kamel مسجد الانصار:** لم يظهر شي

[12:20 PM] **You:** و الأن؟

[12:20 PM] **Dr. Moustafa Kamel مسجد الانصار:** لم يات شيء

[12:21 PM] **Dr. Moustafa Kamel مسجد الانصار:** G-267939 is your Google verification code. Don't share your code with anyone.

[12:21 PM] **Dr. Moustafa Kamel مسجد الانصار:** هذا هو

[12:21 PM] **You:** نعم هذا هو، جزاك الله خيرا

[12:22 PM] **Dr. Moustafa Kamel مسجد الانصار:** واياكم

[12:22 PM] **Dr. Moustafa Kamel مسجد الانصار:** إذا أردت ان تأت اليوم أنا بالبيت  أتفضل

[12:23 PM] **You:** حاضر إن شاء الله

[12:23 PM] **Dr. Moustafa Kamel مسجد الانصار:** عرفني متي ستشرفنا

[12:25 PM] **You:** إن شاء الله إذا لم يشتغل التحميل سأرسل لك، و لكن بفضل الله المساحة كافية

[12:25 PM] **Dr. Moustafa Kamel مسجد الانصار:** تمام

[12:41 PM] **You:** معلش يا شيخ أرسلي لو في رسالة آخرى

[12:41 PM] **Dr. Moustafa Kamel مسجد الانصار:** G-447342 is your Google verification code. Don't share your code with anyone.

---

## October 21, 2026

[2:49 PM] **You:** https://www.instagram.com/reel/DeueGByjJoh/?srtk=c2FubnNpZWwwaTJn

---

## October 23, 2026

[11:06 AM] **Dr. Moustafa Kamel مسجد الانصار:** السلام عليكم ورحمة الله وبركاته حبيبنا 
عندك خطبة اليوم 
ولا ستترجم

[11:06 AM] **You:** وعليكم السلام عليكم ورحمة الله وبركاته شيخنا الحبيب 
نعم بإذن الله عز وجل عندي خطبة

[11:41 AM] **Dr. Moustafa Kamel مسجد الانصار:** The Danger of Temptations and the Lifeline of Salvation

It was mentioned in the hadith on the authority of Abu Hurairah, on the authority of the Prophet ﷺ, who said:

“Time will pass quickly, knowledge will decrease, miserliness will be cast into people’s hearts, tribulations will appear, and there will be much Harj.”

They said, “O Messenger of Allah, what is Harj?” He said, “Killing.”

In another narration: “Time will pass quickly, and knowledge will decrease.” (Muslim)

Temptations have increased in our days, and Allah’s trials through temptations are countless. It is as if the world today is on the verge of a third world war. Whenever we say that the war in Gaza is nearing its end, we see the situation becoming worse. And we say: “Peace—a word from a Merciful Lord.”

Through this noble hadith, I would like to highlight some of the dangers of temptations for Muslims and the lifeline of salvation from them.

First: The Danger of Temptations for Muslims

There are many dangers during times of temptation. We mention some examples:

1. Shaking the Foundations of Faith

We find an example of this in the Qur’an, where Allah Almighty says:

“Among the people is he who worships Allah on an edge: if good befalls him, he is reassured by it; but if a trial befalls him, he turns back on his face. He loses this world and the Hereafter. That is the clear loss.” (11) [Al-Hajj 22:11]

We also find it in the hadith narrated by Abu Hurairah, may Allah be pleased with him, that the Prophet ﷺ said:

“Rush to do good deeds before tribulations come like portions of a dark night. A man will wake up as a believer and become a disbeliever by evening, or he will enter the evening as a believer and wake up as a disbeliever in the morning. He will sell his religion for worldly goods.”

(Muslim)

2. Deviation from Good Morals

During times of temptation, corruption spreads on earth and morals deteriorate.

Allah Almighty said:

“When We intend to destroy a town, We command its affluent ones, but they commit wickedness therein. Thus the decree becomes due against it, and We destroy it completely.” [Al-Isra 17:16]

Ibn Khaldun said: “When Allah permits the decline of a kingdom belonging to a nation, He drives them to commit blameworthy acts, adopt vices, and follow their paths.”

This is what happened in Andalusia and ultimately contributed to its loss.

We have witnessed in our painful reality in this era how morals have been corrupted by the misconduct of rulers and their corruption on earth. As a result of the imprisonment of scholars who provided religious guidance and direction, and their replacement with scholars of entertainment, morals deteriorated, societies became corrupt, and sexually transmitted diseases appeared in abundance in the lands that were the cradle of Islam, after such matters had been controlled during the days of sincere scholars.

3. Loss of Pride and Dignity

During times of temptation, faith becomes weak, a person’s pride and dignity diminish, and people submit to oppressors.

Adi ibn Hatim came to the Prophet ﷺ while he was a Christian, and he heard the Prophet reciting this verse:

“They have taken their rabbis and monks as lords besides Allah, as well as the Messiah, son of Mary. Yet they were commanded to worship only One God. There is no deity worthy of worship except Him. Glory be to Him above what they associate with Him.” [At-Tawbah 9:31]

Adi said, “We do not worship them.”

The Prophet ﷺ said, “Do they not forbid what Allah has made lawful, so you also forbid it, and make lawful what Allah has forbidden, so you also make it lawful?”

Adi replied, “Yes.”

The Prophet ﷺ said, “That is their worship.”

(At-Tirmidhi)

Today, we do not find a people who uphold their pride and dignity like the people of Gaza, who refuse to be servants of anyone but Allah Almighty.

We have also witnessed America’s objection to Palestine’s membership in the United Nations, which confirms the words of Allah Almighty:

“Never will the Jews or the Christians be pleased with you until you follow their religion.” (120) [Al-Baqarah 2:120]

Second: The Lifeline of Salvation and Steadfastness During Times of Temptation

1. Adherence to the Qur’an and Sunnah

Allah Almighty said:

“Those who disbelieved said, ‘Why was the Qur’an not revealed to him all at once?’ It was revealed in this way so that We may strengthen your heart with it, and We have recited it distinctly.” (32) [Al-Furqan 25:32]

The Prophet ﷺ said:

“I have left among you that which, if you hold firmly to it, you will never go astray after me: the Book of Allah and my Sunnah.”

In another narration: “And my family.”

2. Adherence to Faith

Allah Almighty said:

“Allah keeps firm those who believe with the firm word in the life of this world and in the Hereafter. And Allah leaves the wrongdoers to stray. And Allah does what He wills.” (27) [Ibrahim 14:27]

We witnessed the strength of faith in Ka’b ibn Malik when the king of Ghassan sent him an offer of worldly possessions, wealth, and whatever he desired. Yet Ka’b remained steadfast in his faith, with Allah’s help.

We have witnessed this steadfastness in the proud youth, women, and children of Gaza in our time.

May Allah have mercy on Sheikh Kishk, who described the occupiers as a cancer destroying this Ummah. This cancer will not be eradicated except through youth whose goal is to please Allah, whose constitution is the Qur’an, and whose highest aspiration is death in the path of Allah.

3. The Company of Righteous People

Allah Almighty said:

“Close friends on that Day will be enemies to one another, except for the righteous.” (67) [Az-Zukhruf 43:67]

The Messenger of Allah ﷺ likened a good companion to someone who offers you musk. If he does not give you any, at least you will smell its pleasant fragrance.

As for a bad companion, he is like someone blowing a blacksmith’s bellows: either he burns you with its fire, or you smell an unpleasant odor from it.

4. Avoiding Places of Temptation

Allah Almighty said:

“And fear a trial that will not afflict exclusively those among you who have done wrong.” (25) [Al-Anfal 8:25]

Allah Almighty also said:

“O you who believe! Indeed, among your spouses and your children are enemies to you, so beware of them. But if you pardon, overlook, and forgive, then indeed Allah is All-Forgiving, Most Merciful.” (14) [At-Taghabun 64:14]

The Prophet ﷺ said:

“Avoid doubtful matters, for whoever avoids doubtful matters has protected his religion and his honor, and whoever falls into doubtful matters falls into the forbidden.”

(Agreed upon by Al-Bukhari and Muslim)

Conclusion

1. The abundance of temptations may lead to weak faith, humiliation, and indignity, especially when countries fall under the rule of oppressors and criminals.
2. Temptations have destructive effects on individuals and society. We have witnessed the spread of immoral acts and adultery in these days because of the abundance of temptations.
3. There is no salvation from temptations except by adhering to the Book of Allah Almighty and the Sunnah of His Messenger ﷺ, keeping the company of righteous people, and avoiding places of temptation.

[11:42 AM] **Dr. Moustafa Kamel مسجد الانصار:**
> _You: وعليكم السلام عليكم ورحمة الله وبركاته شيخنا الحبيب 
نعم بإذن الله عز وجل عندي خطبة_
وفقكم الله

[11:50 AM] **You:** آمين و إياكم

---

## November 2, 2026

[3:55 PM] **You:** السلام عليكم ورحمة الله وبركاته، شيخنا الحبيب.
نسأل الله أن تكونوا بخير، وأن تكونوا قد وصلتم بالسلامة. هل سيكون هناك درس الليلة إن شاء الله؟

[4:35 PM] **Dr. Moustafa Kamel مسجد الانصار:** وعليكم السلام ورحمة الله وبركاته حبيبنا 
الله يسلمكم 
اليوم درس بعد المغرب ان شاء الله تقريبا الساعة ال5:45

[4:37 PM] **You:** جزاكم الله خيرا، نراكم بإذن الله عز و جل

[4:50 PM] **Dr. Moustafa Kamel مسجد الانصار:** واياكم

---

## November 3, 2026

[2:24 PM] **Dr. Moustafa Kamel مسجد الانصار:** [Voice message]

[9:23 PM] **You:** [Voice message]

[10:24 PM] **You:** السلام عليكم ورحمة الله وبركاته شيخنا الغالي
هل ممكن ترسل لي نسخ PDF من كتبك، إن كانت متاحة؟ جزاك الله خيرا

[11:12 PM] **Dr. Moustafa Kamel مسجد الانصار:** وعليكم السلام ورحمة الله وبركاته حبيبنا 
حاصر ان شاء الله

---

## November 7, 2026

[4:56 AM] **Dr. Moustafa Kamel مسجد الانصار:** السلام عليكم ورحمة الله وبركاته حبيبنا 
يارب تكونوا بخير 
إذا عند حضرتك وقت اليوم انفصل نصلي الظهر ونكمل الشغل

[4:56 AM] **Dr. Moustafa Kamel مسجد الانصار:** جزاكم الله خيرا

[5:07 AM] **You:** و عليكم السلام ورحمة الله وبركاته 
أبشر يا شيخنا بإذن الله عز وجل

[5:07 AM] **You:** و إياكم

[2:43 PM] **Dr. Moustafa Kamel مسجد الانصار:** [Document] بحث الدكتوراه انتهيت منه تماما    بصيعة الوورد.docx

[2:46 PM] **Dr. Moustafa Kamel مسجد الانصار:** الاسم مصطفي سليمان كامل
التخرج 1992 من الشريعة والقانون قسم القانون بالأزهر الشريف
وقد شرفني الله تعالي بحفظ القران الكريم وانا صغير في الحادية عشرة من عمري
حاصل علي
١- اجازة في القران الكريم حفظا وتجويدا برواية حفص عن عاصم
٢ -اجازة في القران الكريم حفظا وتجويدا برواية قالون عن نافع
٣- اجازة في علم الحديث رواية ودراية
٤- ماجستير في الفقه المقارن في الزواج برؤية مقاصدية2013
٥- دكتوراة في الفقه المقارن بعنوان. الفرقة بين الزوجين في الشريعة الاسلامية وقانون الاسرة الامريكي في كاليفورنيا 
العمل2015
قبل التخرج كنت أخطب وادرس بالمساجد
١- محاميا من 1992-1994
٢- عملت امام وخطيب بالاوقاف المصرية من ١٩٩٤-١٩٩٩ 
حيث احالوني الي عمل اداري 
٣- عملت بتدريس اللغة العربية والعلوم الشرعية 
٤- جئت أمريكا ٢٠٠٣ وعملت بمسجد الانصار بكاليفورنيا 
West coast Islamic society 
 الي يومنا هذا امام المركز الاسلامي

[2:54 PM] **Dr. Moustafa Kamel مسجد الانصار:** [Document]      -     .pdf

[2:58 PM] **Dr. Moustafa Kamel مسجد الانصار:** Hi,
Here's the file "كتاب الفرقة بين الزوجين بتاريخ 5-5- 2016 تمت مراجعته وجاهز للطبع 15-13-47-020.pdf" for your review.
https://acrobat.adobe.com/id/urn:aaid:sc:US:ce022280-ab16-4d56-81e5-fdf93b1a053b

Add your comments and collaborate with others in real time. You don't need to download Acrobat to access the file.

[2:59 PM] **Dr. Moustafa Kamel مسجد الانصار:** [Document] مسائل في مشكلات الحياة الزوجية.docx

[3:01 PM] **Dr. Moustafa Kamel مسجد الانصار:** https://docs.google.com/document/d/1N9fPxvSCPUaK5bR__L0kUIOnaXhLnzEEl40D0_mTrao/edit?usp=drivesdk

[3:32 PM] **You:** Check out Muse, your personal AI agent. Redeem my code in Settings within 48 hours of joining and we'll both get 1 billion Muse tokens.

Code: BA13UJ
https://muse.ai/join

[3:41 PM] **You:** [Forwarded] Sheikhmostafakamel@gmail.com
Password : Yusuf@2007!

[7:38 PM] **Dr. Moustafa Kamel مسجد الانصار:** [Document] Noor-Sprouts-Newsletter-01-EN.pdf

---

## November 8, 2026

[8:29 PM] **Dr. Moustafa Kamel مسجد الانصار:** https://youtube.com/playlist?list=PLOnQH7epGUf4&si=pRc8cEuzXdtLG5-4

[10:50 PM] **You:** جميل ما شاء الله

---

## November 13, 2026

[5:17 AM] **Dr. Moustafa Kamel مسجد الانصار:** فضل صلة الأرحام
The Virtue of Maintaining Family 
First Khutba

All praise is due to Allah, the Most Compassionate, the Most Merciful. We praise Him, seek His help and forgiveness, and seek refuge in Him from the evil within ourselves and from our misdeeds. I bear witness that there is no deity worthy of worship except Allah alone, without partner, and that Muhammad is His servant and messenger. May Allah send peace and blessings upon him, his family, and his companions.

Servants of Allah, I urge you and myself to be mindful of Allah. He calls on believers to be mindful of Him as He deserves and to remain in submission to Him until death (Qur’an 3:102). He also reminds us that He created humanity from a single soul, commands us to honor the ties of kinship, and tells us that He is always watching over us (Qur’an 4:1).

Brothers and sisters, when was the last time we called a relative simply to ask how they were doing? Do we know who in our family is sick, lonely, or struggling to pay a debt? Maintaining family ties, or silat al-rahim, is an act of worship. Allah commands justice, excellence, and generosity toward relatives, and He tells us to give relatives their due (Qur’an 16:90 and 30:38).

Begin with your parents, then give attention to your closest relatives. Visit when you can, speak kindly, offer support in hardship, make du‘a for them, and help reconcile those who are at odds. What you can offer will depend on your means and what your relatives need. The Prophet, peace and blessings be upon him, said, “Whoever believes in Allah and the Last Day should maintain their family ties.” (Al-Bukhari)

The Reward of Keeping Family Ties

The Prophet, peace and blessings be upon him, taught that whoever wishes for their provision to be expanded and their lifespan extended should maintain their family ties (Al-Bukhari and Muslim). These blessings come according to Allah’s decree. Allah can bless modest means so that they suffice, and He can fill a person’s years with worship and service. Even a small gesture can reassure a parent or bring relief to a household in need.

A man once asked the Prophet what deed would lead him to Paradise. The Prophet told him to worship Allah alone, establish prayer, give zakat, and maintain family ties (Al-Bukhari and Muslim). He also gave a grave warning about severing kinship ties (Al-Bukhari and Muslim). The Qur’an likewise warns those who spread corruption and cut off their relatives (Qur’an 47:22–23). Take this as a call to repent and repair what you can while there is still time.

The Prophet taught that truly maintaining family ties means reaching out even when relatives have cut you off (Al-Bukhari). If a disagreement has kept you from speaking to your brother or uncle, you might begin by offering salam or asking how they are. When Khadijah comforted the Prophet after the first revelation, she recalled how faithfully he kept his family ties and helped people in need. When Abu Talhah wished to give away his beloved garden, the Prophet encouraged him to give it to his relatives.

When disputes arise over money, inheritance, or hurtful words, be fair even when you are angry. Guard your speech, respect each person’s rights, and seek reconciliation where possible. Part of helping a relative who is acting unjustly is stopping them from doing harm.

I say these words and ask Allah Almighty to forgive me, you, and all Muslims. Ask Him for forgiveness. He is the Most Forgiving, the Most Merciful.

Second Khutba

All praise is due to Allah, Lord of the worlds. We thank Him for His blessings. I bear witness that there is no deity worthy of worship except Allah alone and that Muhammad is His servant and messenger. May Allah send peace and blessings upon him, his family, and his companions.

Servants of Allah, begin with your parents. Call them, visit if you can, ask about their health, and pray for them often. If you live far away, set aside a regular time to call. A few minutes of conversation can ease an older relative’s loneliness. Check on siblings, grandparents, aunts, and uncles. If someone is sick, out of work, or in debt, offer what you can and protect their dignity. An errand or a kind word may be what they need that day.

When a disagreement is hard to resolve, ask someone wise and fair to help. If you have wronged a relative, restore what is owed and ask for forgiveness. Where there is serious harm, seek protection and advice, and keep whatever contact is safe and appropriate. Show kindness across differences of faith as well. When Asma’ bint Abi Bakr asked about keeping ties with her mother, who did not share her faith, the Prophet told her to do so (Al-Bukhari and Muslim).

Distance and busy lives make it easy to lose touch. Use the means you have to stay close, and give your relatives your attention when you speak with them. If you can help someone financially, do so discreetly. You can also make du‘a for them, speak on their behalf when appropriate, or help them take care of something they cannot manage alone.

Putting Family Ties into Practice

Today, call one relative you have not spoken to in months. Set aside time each week to check on family and set aside time each month for a visit when you can. Give a share of your charity to relatives in need. Teach your children who their relatives are and take them along on visits so they can learn what it means to care for family.

Brothers and sisters, think of someone you have not heard from in a long time. Is there a relative who needs food, medicine, or help paying a debt? Is there someone you could visit while they are ill, or a family dispute you could help resolve? Life is short. The chance to hear a loved one’s voice or sit with them may pass before we realize it.

Let today be a new beginning in honoring our parents and caring for our relatives. Reach out to someone you have missed, help someone in need, and seek Allah’s pleasure through the ties He has commanded us to keep.

O Allah, help us maintain our family ties, honor our parents, and treat our relatives with kindness. Reconcile us and bring our hearts together. Bless our provision, our lives, and our deeds. Heal our sick, have mercy on those who have died, and guide us to what pleases You. May Allah send peace and blessings upon our Prophet Muhammad, his family, and his companions. Ameen.

[10:45 AM] **Dr. Moustafa Kamel مسجد الانصار:** [Document] من فضائل القرآن الكريم الثقة الاستقامة نبذ  الباطل.pdf

[10:46 AM] **You:** جزاك الله خيرا شيخنا

[10:46 AM] **You:** نراكم إن شاء الله

[11:56 AM] **Dr. Moustafa Kamel مسجد الانصار:** واياكم

---

## November 14, 2026

[6:42 PM] **Dr. Moustafa Kamel مسجد الانصار:** [Document] �النشرة-التربوية-02-العربية-وحفظ-الدين.pdf

[6:43 PM] **Dr. Moustafa Kamel مسجد الانصار:** [Document] Noor-Sprouts-Newsletter-02-EN.pdf

[6:54 PM] **Dr. Moustafa Kamel مسجد الانصار:** https://acrobat.adobe.com/id/urn:aaid:sc:US:ce022280-ab16-4d56-81e5-fdf93b1a053b

---

## November 16, 2026

[5:59 AM] **Dr. Moustafa Kamel مسجد الانصار:** السلام عليكم ورحمة الله وبركاته حبيبنا 
يارب تكونوا بخير 
اولا جزاكم الله خير على البرنامجmuse
ثانيا 
اشتغلت عليه 
وعملت كتاب الدكتوراة أربع كتب  وسأرسلها لحضرتك 
وسأعمل باقي الكتب ان شاء الله 
وكذلك عملت بعض الخطب كتب 
وسأرسلها لحضرتك 
لنضعها على الويب سايت ان شاءالله 
جزاكم الله خيرا ورفع قدرك وانا. دربك ووفقك لكل خير وجعلك معوانا على الخير وناشر للحق

[11:53 AM] **Dr. Moustafa Kamel مسجد الانصار:** [Document] #16- Series of -Proud To Be Muslims-.pdf

[12:27 PM] **You:** و عليكم السلام ورحمة الله وبركاته شيخنا الحبيب 

ما شاء الله، جزاكم الله خيرا، والله أسعدني جدا سماع هذا الخبر. الحمد لله أن البرنامج كان نافعا لكم، وأسأل الله أن يجعله سببا في الدعوة و نشر علمكم وانتفاع الناس به.
أرسلوا لي الكتب والخطب متى تيسر لكم، وإن شاء الله نعمل على ترتيبها وتجهيزها للموقع.
بارك الله فيكم، ونفع بكم، وجعل هذا العمل في ميزان حسناتكم، ووفقنا وإياكم لكل خير.

[1:52 PM] **Dr. Moustafa Kamel مسجد الانصار:** حاضر 
سأرسلهم

[6:37 PM] **Dr. Moustafa Kamel مسجد الانصار:** [Document] usul-al-fiqh-lessons-ملون.pdf

[6:37 PM] **Dr. Moustafa Kamel مسجد الانصار:** [Document] al-fadila-lessons-ملون.pdf

[6:37 PM] **Dr. Moustafa Kamel مسجد الانصار:** [Document] mas-la-introductions-ملون.pdf

[6:37 PM] **Dr. Moustafa Kamel مسجد الانصار:** [Document] moses-story-book-ملون.pdf

[6:37 PM] **Dr. Moustafa Kamel مسجد الانصار:** [Document] kahf-khutbas-ملون.pdf

[6:37 PM] **Dr. Moustafa Kamel مسجد الانصار:** [Document] prophets-stories-complete-book-ملون.pdf

[6:37 PM] **Dr. Moustafa Kamel مسجد الانصار:** [Document] الفرقة-بين-الزوجين-الجزء الأول-ملون.pdf

[6:37 PM] **Dr. Moustafa Kamel مسجد الانصار:** [Document] الفرقة-بين-الزوجين-الجزء الثاني-ملون.pdf

[6:37 PM] **Dr. Moustafa Kamel مسجد الانصار:** [Document] الفرقة-بين-الزوجين-الجزء الثالث-ملون.pdf

[6:37 PM] **Dr. Moustafa Kamel مسجد الانصار:** [Document] الفرقة-بين-الزوجين-الجزء الرابع-ملون.pdf

[6:55 PM] **Dr. Moustafa Kamel مسجد الانصار:** [Document] فقه-الزواج-الميسر-ملون.pdf

[6:56 PM] **Dr. Moustafa Kamel مسجد الانصار:** _This message was deleted_

---

## November 17, 2026

[10:51 AM] **Dr. Moustafa Kamel مسجد الانصار:** [Document] الخيانة-الزوجية-وسبل-التعامل-معها-ملون.pdf

[12:47 PM] **Dr. Moustafa Kamel مسجد الانصار:** [Forwarded] [Image]

[3:07 PM] **Dr. Moustafa Kamel مسجد الانصار:** [Document] خطب-رمضان-ملون.pdf

[3:08 PM] **Dr. Moustafa Kamel مسجد الانصار:** [Document] خطب-شعبان-ملون.pdf

[3:08 PM] **Dr. Moustafa Kamel مسجد الانصار:** [Document] خطب-رجب-ملون.pdf

[3:08 PM] **Dr. Moustafa Kamel مسجد الانصار:** [Document] خطب-أول-العام-ملون.pdf

[3:08 PM] **Dr. Moustafa Kamel مسجد الانصار:** [Document] خطب-الحج-ملون.pdf

[3:08 PM] **Dr. Moustafa Kamel مسجد الانصار:** [Document] خطب-العبادات-ملون.pdf

[3:09 PM] **Dr. Moustafa Kamel مسجد الانصار:** [Document] خطب-الإيمان-ملون.pdf

[3:09 PM] **Dr. Moustafa Kamel مسجد الانصار:** [Document] خطب-الموت-والآخرة-ملون.pdf

[3:09 PM] **Dr. Moustafa Kamel مسجد الانصار:** [Document] خطب-سبعة-يظلهم-الله-ملون.pdf

[3:09 PM] **Dr. Moustafa Kamel مسجد الانصار:** [Document] خطب-الأخلاق-ملون.pdf

[3:09 PM] **Dr. Moustafa Kamel مسجد الانصار:** [Document] خطب-تزكية-النفوس-ملون.pdf

[3:10 PM] **Dr. Moustafa Kamel مسجد الانصار:** [Document] خطب-الأسرة-والتربية-ملون.pdf

[3:10 PM] **Dr. Moustafa Kamel مسجد الانصار:** [Document] خطب-المجتمع-والمسلم-في-الغرب-ملون.pdf

[3:10 PM] **Dr. Moustafa Kamel مسجد الانصار:** [Document] خطب-السيرة-النبوية-ملون.pdf

[3:10 PM] **Dr. Moustafa Kamel مسجد الانصار:** [Document] خطب-الهجرة-ملون.pdf

[3:11 PM] **Dr. Moustafa Kamel مسجد الانصار:** [Document] خطب-الأنبياء-ملون.pdf

[3:11 PM] **Dr. Moustafa Kamel مسجد الانصار:** [Document] خطب-الصحابة-ملون.pdf

[3:11 PM] **Dr. Moustafa Kamel مسجد الانصار:** [Document] خطب-الصحابة-ملون.pdf

[3:11 PM] **Dr. Moustafa Kamel مسجد الانصار:** [Document] خطب-قضايا-الأمة-ملون.pdf

[3:11 PM] **Dr. Moustafa Kamel مسجد الانصار:** [Document] خطب-الدعوة-والإصلاح-ملون.pdf

[3:13 PM] **Dr. Moustafa Kamel مسجد الانصار:** [Document] خطب-الدعوة-والإصلاح-ملون.pdf

[3:24 PM] **Dr. Moustafa Kamel مسجد الانصار:** [Document] خطب-الحديث-القدسي-ملون.pdf

---

## November 18, 2026

[11:08 AM] **Dr. Moustafa Kamel مسجد الانصار:** [Document] kahf-khutbas-ملون.pdf

[3:11 PM] **Dr. Moustafa Kamel مسجد الانصار:** [Voice message]

[3:14 PM] **You:** [Voice message]

[3:17 PM] **Dr. Moustafa Kamel مسجد الانصار:** [Voice message]

[5:48 PM] **Dr. Moustafa Kamel مسجد الانصار:** [Voice message]

[5:52 PM] __[Call]__

[6:30 PM] **Dr. Moustafa Kamel مسجد الانصار:** [Document] وقفات-من-السيرة-النبوية-الجزء-الأول-ملون.pdf

[6:31 PM] **Dr. Moustafa Kamel مسجد الانصار:** [Document] educational-reflections-on-the-seerah-part-one.pdf

[6:31 PM] **Dr. Moustafa Kamel مسجد الانصار:** [Document] وقفات-من-السيرة-النبوية-الجزء-الثاني-ملون.pdf

[6:31 PM] **Dr. Moustafa Kamel مسجد الانصار:** [Document] educational-reflections-on-the-seerah-part-two.pdf

[6:49 PM] **You:** [Forwarded] [Image]

[6:49 PM] **You:** [Forwarded] [album message]

[6:49 PM] **You:** [Forwarded] [Image]

[6:49 PM] **You:** [Forwarded] [Image]

[6:49 PM] **You:** [Forwarded] [Image]

[7:38 PM] **Dr. Moustafa Kamel مسجد الانصار:** 24130. Wright

[7:41 PM] **Dr. Moustafa Kamel مسجد الانصار:** [album message]

[7:41 PM] **Dr. Moustafa Kamel مسجد الانصار:** [Image]

[8:08 PM] **Dr. Moustafa Kamel مسجد الانصار:** [Image]

[8:08 PM] **Dr. Moustafa Kamel مسجد الانصار:** [Image]

[8:08 PM] **Dr. Moustafa Kamel مسجد الانصار:** [Image]

[8:08 PM] **Dr. Moustafa Kamel مسجد الانصار:** [Image]

---

## November 19, 2026

[12:37 PM] **Dr. Moustafa Kamel مسجد الانصار:** [Document] kahf-khutbas-ملون.pdf

[6:47 PM] **Dr. Moustafa Kamel مسجد الانصار:** [Voice message]

---

## November 20, 2026

[1:00 AM] **You:** [Voice message]

[1:01 AM] **You:** [Voice message]

[4:53 AM] **Dr. Moustafa Kamel مسجد الانصار:** وعليكم السلام ورحمة الله وبركاته 
محمد اللقاني عمل واحد كمان ممكن تتصل به وتشوف ايه الافضل معه

[11:14 AM] **Dr. Moustafa Kamel مسجد الانصار:** _This message was deleted_

[11:14 AM] **Dr. Moustafa Kamel مسجد الانصار:** _This message was deleted_

[12:37 PM] **Dr. Moustafa Kamel مسجد الانصار:** [Document] إضاءات-من-سورة-الفاتحة-خواطر-العشاء-ملون.pdf

[12:37 PM] **Dr. Moustafa Kamel مسجد الانصار:** [Document] illuminations-from-surah-al-fatiha-dinner-reflections.pdf

[12:40 PM] __[Call]__
